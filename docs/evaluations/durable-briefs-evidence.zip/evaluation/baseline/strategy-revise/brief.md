# Orbit Garden strategy — first-use revision, 2026-10-08

## Audience and promise

Relaxing-game fans who want a five-minute break. Grow a little world in one short round. The project still aims to learn whether 20 new players return for a second session. This week's work addresses the first-session prerequisite.

## Channel choice and rationale

Pause increasing reach. Make direct observation through the existing orbit-playtest initiative the priority for October 9–15. Retain the existing YouTube clip as one bounded discovery test; do not add clips, distribution or ad spend this week. Its rationale remains plausible: seeing the visible payoff may attract intended players. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand or a verdict against YouTube. Reddit remains a conditional alternative pending community fit and posting permission; no new community or permission has been researched for this revision.

Direct observation fits the question because it exposes what happens between arrival and the first action. The cost is scheduling and a biased sample of three volunteers; it gives diagnostic detail, not channel-effectiveness estimates. Continuing content production now would consume scarce maker time while leaving first-use confusion unresolved. Reusing the current channel later has lower setup and maintenance cost than introducing another channel and attribution path. None of this requires a new recurring channel commitment.

## Assumptions and evidence

All counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence; local provenance is the observation/reaction IDs below. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.

October 1–7 observations orbit-visitors and orbit-starts give 90 and 8. The 8.9% ratio is descriptive only: unique identities and equivalent definitions are unverified. orbit-returns records one return, but it does not support a 12.5% retention claim. Weekly and daily view series overlap and must not be summed.

Reviewed r1 describes not knowing which seed to choose; reviewed r2 asks about saving and returning; reviewed r4 describes a fun first round. Unreviewed r3 flags possible phone-control trouble and r5 asks what happens after five minutes. Inspect these in sessions without treating comment counts as representative. The existing randomized label-versus-hint experiment has 18 and 21 assignments, below its 100-per-arm target and stipulated full seven-day window; do not declare a winner or mix moderated observations into it.

Assumptions to check: intended players are available for three sessions; the current build can be used consistently; the difficulty is first-use understanding rather than technical failure, targeting or measurement error. Do not implement a hint before observing where people hesitate.

## Effort and next decision

Owner: Family studio. Limit this week to three maker-hours and no ad spend. Allocate 30 minutes to scheduling and preparing a stable build and notes; 60 minutes to three 20-minute first-session appointments; 30 minutes to consolidate observations and verify event definitions; 30 minutes to the review and next-change specification; 30 minutes buffer. A product fix larger than the remaining time becomes next week's scoped work. Stop at the cap; report missing sessions openly.

Use three first-time players interested in relaxing games. Include a phone user if available, given r3, and record all devices. Give the same neutral task: “Try a round and describe where you hesitate.” Allow five minutes of unaided play before debriefing. Record first meaningful action and elapsed time, seed-choice hesitation, control errors, first-round completion, prompts/help and the player's own words. If someone needs help, label subsequent success assisted. Ask afterward how they would resume later; distinguish expressed intent from an observed return. Keep the build constant across these three sessions.

Review on 2026-10-15. Keep distribution paused until this review. If two players share a point of confusion, specify one small change there, then observe again before increasing reach. If all three perform the first action unaided and at least two finish the round without a shared blocker, revisit one bounded YouTube iteration the following week. If the build is broken, stop sessions and fix the blocker first. Fewer than three sessions or unclear instrumentation means incomplete evidence. These are operating rules for a tiny diagnostic sample, not statistical proof of improvement.

Revisit channel choice when first-use observations separate the explanations: clear first use plus mismatched interests among attributed arrivals suggests an audience/message problem; persistent first-action confusion among intended players suggests a product problem; no suitable direct volunteers within the time cap suggests a recruitment-access problem. Only the first or third is a reason to compare another channel. Reddit would require a specific suitable community and verification that the intended participation is welcome before any plan to post.

Then measure starts and return use with consistent definitions and preserved attribution. Define a cohort of distinct first-time starters, record their entry dates and source, and allow each a full seven days for a second session; report eligible cohort size and observed repeat sessions separately from assisted playtests. No claim about payment intent follows from this data. This revision preserves the original audience, payoff hypothesis, conditional alternative, time limit and October 15 review while making the first-session observation priority concrete.
