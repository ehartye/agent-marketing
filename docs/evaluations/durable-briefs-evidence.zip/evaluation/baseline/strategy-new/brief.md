# Orbit Garden: weekly channel strategy

Decision, 2026-10-08: use direct, individually scheduled playtests as this week's active channel. Prioritize three first-time players during October 9–15. Keep the existing YouTube initiative as background evidence, with no new reach push this week. Owner: Family studio. Spend: $0; maker time: three hours maximum. The user's zero-ad constraint overrides the project's illustrative $300 budget for this plan.

The audience remains indie players and relaxing-game fans seeking a five-minute break. The promise is “Grow a little world in five minutes”; the immediate CTA is “Try a round and describe where you hesitate.” The longer-term objective of 20 new players returning for a second session remains, but this week tests a prerequisite rather than claiming to reach that objective.

## Evidence and assumptions

All evidence here is supplied synthetic data, not live market research. In October 1–7, orbit-video has 2,400 views, 90 visitors, 8 starts and 1 return (observation IDs orbit-views, orbit-visitors, orbit-starts, orbit-returns). The daily view series also sums to 2,400; do not add it to the weekly total. Eight divided by 90 is an observed count ratio of 8.9%, not a verified unique-user conversion rate. The single return is not a retention rate because identities, eligibility and the return window are unspecified.

Reviewed reaction r1 names seed-choice confusion; r2 asks about saving and returning; r4 reports an enjoyable first round. Unreviewed r3 suggests phone-control confusion and r5 asks what follows five minutes; these are leads to observe, not validated prevalence. The existing hint experiment has only 18 and 21 assignments against its 100-per-arm stopping target. Do not select a winner or fold moderated playtests into those counts.

Working assumption: first-action friction is a more useful near-term question than insufficient reach. The counts and comments do not establish causality or prove YouTube has the wrong audience. Another assumption is that three suitable first-time players are accessible without paid recruitment. If access fails, record that shortfall rather than replacing observation with more content production. The illustrative alternatives suggest a five-minute game competes with simply watching a relaxing video; this is positioning context, not researched competitor performance.

## Channel tradeoffs

| Choice | Time and lag | Risk | Complexity and practice | Maintenance |
|---|---|---|---|---|
| Direct playtests: choose this week | Three hours including scheduling, sessions and review; scheduling may delay the third session | Familiar volunteers and moderation can bias behavior; three sessions cannot estimate population rates | One consistent task and a small observation sheet; appropriate for locating friction before a larger test | Short-lived scheduling effort and one review, no content cadence |
| Additional organic YouTube clip: defer | Existing brief allows one hour preparation, leaving less observation time; responses may arrive after the week | More views could send players into the same difficulty; effectiveness is unproven | Reuses current assets and tagged-link plan, but requires compatible start and cohort measures | Requires capture, publication and response handling for each iteration |
| Paid or additional channels: defer | Ads conflict with $0; another organic channel adds setup and response time | Spend or fragmented tiny samples can obscure the question | Extra attribution and channel-specific operations are disproportionate this week | Another recurring production and monitoring obligation |

## One next test

Run the planned orbit-playtest with three people who have never played and who enjoy relaxing games. Use the same current build and neutral invitation for all. Ask each to try a five-minute round; let them choose the first action without prompting. Record device, time to first meaningful action, successful action, first-round completion, exact hesitation and any help given. Assistance makes that attempt assisted, not an independent success. Ask afterward what they expected first and whether they can find how to resume. Do not change the build between these sessions or claim a controlled intervention effect.

Time allocation: 30 minutes to prepare the build, observation sheet and scheduling; 60 minutes for three 20-minute sessions; 30 minutes to consolidate notes and check tracking; 30 minutes for the review; 30 minutes buffer. Stop additional preparation when the 180-minute cap is reached. No outreach or spending occurs as part of this saved plan.

## Review decision

Review October 15, or earlier for a broken flow. Continue toward one bounded YouTube iteration next week only if all three players complete the first action unaided, at least two complete a round, and there is no repeated blocking issue. If two encounter the same hesitation, prioritize that specific first-use change and another observation round; keep reach expansion paused. Stop the test for a broken or inaccessible build, or the time cap, and record what remains unknown. Fewer than three completed sessions means incomplete evidence, not success. These are practical triage thresholds, not statistical validation.

Reconsider the channel choice after a usable first session is demonstrated: if suitable volunteers cannot be reached within the time cap, or subsequent attributed YouTube players consistently differ from the intended audience, compare a different recruitment channel. Define a separate first-session cohort and a seven-day second-session window before interpreting returns; later entrants need their full follow-up time. The broader concern is activation and return-use clarity, so increased reach alone will not answer the project's return objective.
