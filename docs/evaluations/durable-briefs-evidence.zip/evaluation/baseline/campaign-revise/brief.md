# A planet in one coffee break — revised campaign plan

Initiative: orbit-video. Channel: YouTube. Owner: Family studio. Existing campaign dates: October 1–14, 2026; review October 14. Budget: $0. Clip preparation remains capped at one hour. Pause if preparation or support exceeds the existing cap; count both when judging whether this iteration fits the hour. This is a planning revision; no clip has been captured or published. Preserve the initiative's recorded running status as historical context, not evidence that this revision is live.

## Audience and hypothesis

For relaxing-game fans wanting a five-minute break. Keep the original idea that showing a tiny world grow can bring players who complete a first round. The revised creative hypothesis is that seeing the first action before its payoff helps viewers understand how to begin. This remains a hypothesis, not validated improvement.

The saved strategy still prioritizes observing first use before increasing distribution. This brief prepares one revision for that bounded test; it does not authorize a wider reach push. The synthetic October 1–7 record has 90 visitors and 8 starts. Reviewed reaction r1 says the player did not know which seed to choose, while unreviewed r3 mentions phone controls. They motivate the opening sequence but do not establish causal explanation or prevalence.

## Revised caption

“Start with a seed. Watch a little world grow. Orbit Garden is a five-minute break you can play. Play a five-minute round: [initiative-tagged try link]”

The seed wording follows supplied reaction r1; verify it against the actual current build before production. Do not promise saving, a particular control gesture or additional features that the workspace does not establish. Replace the bracketed link only with the verified game destination using the existing initiative attribution. The evidence URL is not a playable destination.

## Capture outline

Aim for a simple 15–20 second gameplay capture, without an opening payoff montage:

| Time | Capture | Text or purpose |
|---|---|---|
| 0–3 seconds | Begin at the real fresh-play screen. Keep the seed choice and relevant controls legible; no fully grown world first. | “Start here.” Establish the first decision. |
| 3–7 seconds | Show the actual pointer/touch interaction selecting the initial seed and any required next input, in order. Keep this action at real speed. | “Your first seed.” Use the actual UI label if different. Do not invent an interface or skip a necessary step. |
| 7–14 seconds | Show the resulting visible growth/payoff from that action. Use a continuous capture if practical; mark any accelerated growth or elapsed-time cut clearly. | “Watch your little world grow.” Connect action to result without implying instant effects. |
| 14–20 seconds | Hold a readable gameplay result and the invitation to try. | “Play a five-minute round.” The same CTA as the existing initiative. |

The current build and actual mechanics have not been inspected in this synthetic exercise. If seed selection is not the first meaningful action, substitute the real first action and its exact label before capture; keep the action-before-payoff order. No final video asset is claimed here.

One-hour allocation: 10 minutes to confirm the opening and link; 20 for one clean capture; 15 for trimming and readable text; 10 for mute/small-screen review and action-order verification; five buffer. Support effort consumes the same bounded iteration allowance; pause when it no longer fits. Use existing gameplay and assets; avoid an additional production pipeline.

## Measurement and attribution

Keep the initiative-tagged try-link plan. Retain the campaign key `orbit-video` and any existing source/medium values when the real link is supplied. No concrete destination or prior parameter values appear in the workspace, so none have been invented. If a content/version tag is available, append a version such as `first-action-v2` without changing the campaign attribution; record the eventual live date and creative version before collecting data.

Record attributed visitors and in-game starts over the same exact reporting period, with start-event and unique-user definitions written down. Opening a page is a visit; define a start using the real in-game event before collection. Where identities are available, deduplicate within the period and distinguish test/owner visits. Treat the visitor-to-start ratio as a count ratio if identities cannot be reconciled. Record first-action understanding/completion and repeated hesitation from direct observations separately, tagged by exposure to this revised clip; do not treat these as organic YouTube conversions.

Preserve a separately defined return cohort: distinct first-time starters attributed to orbit-video, each with an entry timestamp, and a second distinct session within the next seven days. Report eligible entrants, returns and incomplete follow-up separately. A starter on October 14 only completes that window on October 21; October 14's campaign review must mark that return evidence pending. Asking whether someone would return is not a return event.

Inspect campaign results with `node scripts/marketing.mjs report --project orbit --initiative orbit-video --workspace .agent-marketing/brief-eval/baseline/campaign-revise/workspace.json`. Use actual matching dates for any later live report. In this exercise, existing October 1–7 observations are synthetic historical illustration, not results of the revised creative. Weekly 2,400 views and the overlapping daily series must not be added together. Reach alone is not success; 8 starts/90 visitors is an unverified observed ratio, and 1 return cannot define retention. A before/after change in such small counts would not prove creative causality.

## Review decision

On October 14, continue consideration of this bounded clip only if observed first-time players can explain and complete the first action unaided, the action in the clip matches the current game, the tagged try path works, and the one-hour/$0 limits hold. Use the strategy's three planned first-session observations where available; record who actually saw the revision, because clip-assisted comprehension and unaided onboarding are different questions.

Change the opening/try path if the same hesitation recurs in two observations. Identify whether the instruction was absent in the clip or difficult in the game before choosing the change. A clearer clip may only compensate for a confusing game opening; that product issue would still need its own scoped fix.

Pause if the flow is broken, preparation/support exceeds the cap, or there is no first-use evidence by the review date. Missing evidence is not a reason to keep expanding reach. Return-cohort follow-up can occur after the campaign review without silently extending the publishing window. No campaign dates, owner, CTA, budget, or existing observation records are changed by this document revision.

## Evidence and limits

The saved Orbit Garden strategy supplies the shared rationale. Demo source: https://example.com/demo-evidence, a supplied synthetic placeholder rather than a retrieved live source. Observations and comments do not establish channel effectiveness, market demand, payment intent or causal effect. No current platform-policy claims are made. Publishing remains outside this planning task.
