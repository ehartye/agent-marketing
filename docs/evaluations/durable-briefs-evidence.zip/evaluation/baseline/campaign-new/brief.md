# First round playtest: campaign plan

Initiative: orbit-playtest. Project: Orbit Garden. Channel: direct. Status: planned; nothing has been sent. Owner: Family studio. Window: October 9–15, 2026. Review: October 15. Budget: $0. Total maker time: at most three hours, consistent with the saved strategy.

## Goal and basis

Observe three first-time players who enjoy relaxing games attempting one five-minute round. Locate first-action hesitation and decide what to change before increasing distribution. Retain the initiative hypothesis, “A clearer first action improves successful starts,” as a hypothesis: three observations of the current build will diagnose friction but cannot show that a change caused improvement. Testing a revised build would require a subsequent test.

The supplied synthetic YouTube records show 90 visitors and 8 starts during October 1–7. Reviewed reaction r1 identifies seed-choice confusion; unreviewed r3 suggests confusing phone controls; reviewed r2 raises saving/returning. Those inform observation topics, not recruitment claims or proven rates. All underlying evidence is synthetic and its example.com URL is a placeholder. No playtest results yet exist. Keep this plan separate from the existing randomized hint experiment and from YouTube traffic counts.

## Ready-to-use message

“Hi [name] — we're looking for three people who enjoy relaxing games and haven't tried Orbit Garden. It's a little world you can grow during a five-minute break. Would you join a 15-minute session between October 9 and 15? You'll try a round while we watch where the game is clear or confusing, then tell us what you expected. We're testing the game, so getting stuck is useful feedback. There's no purchase or payment involved. If you're interested, reply with a time and whether you'd use a phone or computer. Try a round and describe where you hesitate.”

Use the invitation only after the owner chooses to run outreach; no recipients are selected or contacted by this plan. Do not send gameplay instructions in advance. For a scheduled participant, use: “Here's the game for our session: [verified play link]. Please wait until we start so we can see your first experience.” The actual play URL is absent from this workspace; the owner must supply and smoke-test it before running. Do not substitute the evidence placeholder as a playable destination.

## Preparation and session outline

Prepare one stable build and a clean first-use state. Check it opens on supported devices and note the version. Recruit exactly three eligible first-time volunteers; try to include a phone user because of r3, without claiming this sample represents all devices. Keep recruitment and scheduling within 30 minutes; if three cannot be scheduled by the review date, report the shortfall.

Each appointment is 15 minutes plus five minutes for notes:

1. Minutes 0–2: confirm first-time status and device; explain that notes are being taken and ask permission for any optional recording. Notes alone are sufficient. Say: “We're testing the game, not you. Try a round and describe where you hesitate. You can stop whenever you want.”
2. Minutes 2–7: open the fresh game and start a five-minute timer when the playable screen appears. Let the player act without suggesting a seed, control or hint. Note exact actions, pauses and errors. If asked for help, first ask “What would you try?” If they remain blocked or want assistance, help and timestamp it; subsequent performance is assisted.
3. Minutes 7–11: ask “What did you think you should do first?”, “Where did the result differ from what you expected?” and “What would make you want another round?” Ask where they would look to save or resume, without promising those features exist.
4. Minutes 11–15: clarify observed moments, thank them, and close. Do not ask for a positive review. Returning intent is a quote, not a recorded return.
5. Afterward: take five minutes to complete the observation row; preserve failures and incomplete sessions as well as successes.

Maker-hour allocation: 30 minutes scheduling; 30 build/link/notes preparation; 60 for three appointments and notes; 30 analysis/review; 30 buffer. If preparation, support or scheduling consumes the cap, stop and report which sessions are incomplete. Product changes are the next scoped action, not an unbudgeted extra task.

## What to record

Use participant codes P01–P03, with no invented outcomes. Save one row per session and raw notes locally. Record: date/time, first-time eligibility, device/browser, build version, start/load result, seconds to first meaningful in-game action, whether that action was unaided, seed-choice/control hesitation with timestamps, first-round completion within five minutes (yes/no/unknown), assistance time and content, exact quote, technical failures, early departure and total support minutes. Define the first meaningful action before sessions by checking the real build; for example, a successful seed choice/placement producing an in-game state change if that is the actual opening. Merely opening the page is not a successful first action.

Primary readout: unaided successful first actions out of the three scheduled players, with observed versus missing sessions explicit. Secondary: unaided round completions, repeated hesitation locations, load failures and support time. Use participant-level notes to avoid duplicate counting. Mark help-dependent success separately. Never count a no-show as a demonstrated usability failure.

Attribution: retain initiative orbit-playtest and source direct in the session sheet; the actual play link may use `utm_source=direct&utm_medium=playtest&utm_campaign=orbit-playtest` once the real URL is known. Verify those tags survive navigation before relying on analytics. Owner/test visits must be excluded from participant counts. Logged starts should use a documented in-game event, not merely a tagged visit. Keep observed session counts separate from unverified historical start definitions.

If later measuring return use, define a separate cohort of distinct first-time players, timestamp entry, and count a second distinct session within seven days after each first session. Report eligible cohort and follow-up completeness. October 15's first-use review cannot give seven-day results for someone starting that day; final follow-up for those entrants is October 22. Do not add return events now or infer retention from the existing one-return example.

## Continue, change, stop

At October 15 review, record the three rows, time spent, repeated problems and one next decision:

- Continue to one small subsequent discovery test only if all three take the first action unaided, at least two finish the round unaided within five minutes, and there is no repeated blocking issue. This permits another bounded test, not reach expansion at scale.
- Change one first-use element when at least two players encounter the same hesitation, or an otherwise completed session requires help. Specify the smallest relevant change and observe it with new first-time players next; do not declare this campaign an A/B winner.
- Stop sessions immediately for a broken or inaccessible build or a player choosing to stop. Pause the campaign at the three-hour cap. Repair blockers or revise recruitment before restarting. Fewer than three completed observations means incomplete evidence, not a passed test.

These are qualitative operating thresholds. Three volunteers, observation effects and synthetic context cannot establish market demand, causal lift or payment intent. The saved strategy's distribution pause remains until the first-use question is understood.
