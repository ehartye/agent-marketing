Saved the revised `orbit-video` brief in the isolated workspace and verified it reads back correctly. No publication or external action occurred.

**Revised caption:**

> Start with one small action. Watch a little world grow. Play a five-minute round.

Append the existing initiative-tagged try link; its actual destination is not supplied in this demo.

**Capture outline — approximately 15–20 seconds:**

1. **0–5 seconds:** Show the real first-action screen and the complete input, with the relevant control visible. Name the verified action in a short overlay. Confirm the exact seed/control choice during preparation; the demo does not establish those mechanics.
2. **5–10 seconds:** Hold on that action's immediate visible result.
3. **10–15 seconds:** Show the little world's growth from the same session. Label time compression if used.
4. **15–20 seconds:** Close with “Play a five-minute round” and the existing tagged link in the caption/description.

**Limits retained:** Family studio owns the YouTube campaign; dates remain October 1–14, 2026. Budget stays $0, with one hour maximum for clip preparation inside the strategy's three maker-hours. The asset remains to be produced; this is planning only.

**Measurement:** Keep the initiative-tagged attribution plan. Record attributed visitors and starts for matching periods and consistent definitions. Verify identities and start-event meaning before treating their ratio as conversion; observe first-action and round completion separately. Track a separate cohort of verified new players and second sessions within seven days, reporting mature follow-up and pending players separately. The demo's 90 visitors, 8 starts, and one return do not establish retention or this revision's effect. Reach alone is not success.

**Decision:** Revise the clip as planned and hold distribution expansion. Review on **October 14**, using the three intended-player sessions in the saved strategy. Continue only if players understand and complete the first action; change the try path if the same hesitation repeats; pause if support or preparation exceeds the cap. Incomplete observations remain pending. The strategy review stays October 15. A clearer clip cannot by itself resolve confusing controls in the game.

The full plan is in `artifacts/campaign.md`. Validation passed at workspace revision 1; only the campaign brief and workspace revision changed. Executed save/verification commands are in `artifacts/save-verify.ps1`, with output in `artifacts/save-verify-output.txt`; initial inspection output is in `artifacts/commands-output.txt`.
