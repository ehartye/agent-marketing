$ErrorActionPreference = 'Stop'
$taskRoot = '.agent-marketing/brief-eval/followup-baseline/campaign-revise'
Start-Transcript -Path "$taskRoot/artifacts/save-verify-output.txt"
$before = Get-Content "$taskRoot/workspace.json" -Raw | ConvertFrom-Json -Depth 100
node scripts/marketing.mjs document save campaign orbit-video "$taskRoot/artifacts/campaign.md" --revision 0 --workspace "$taskRoot/workspace.json"
if ($LASTEXITCODE -ne 0) { throw 'Campaign save failed' }
node scripts/marketing.mjs validate --workspace "$taskRoot/workspace.json"
if ($LASTEXITCODE -ne 0) { throw 'Workspace validation failed' }
node scripts/marketing.mjs document show campaign orbit-video --workspace "$taskRoot/workspace.json"
if ($LASTEXITCODE -ne 0) { throw 'Campaign readback failed' }
$after = Get-Content "$taskRoot/workspace.json" -Raw | ConvertFrom-Json -Depth 100
$saved = ($after.initiatives | Where-Object id -eq 'orbit-video').brief.markdown
$expected = Get-Content "$taskRoot/artifacts/campaign.md" -Raw
if ($saved.Trim() -ne $expected.Trim()) { throw 'Saved brief differs from artifact' }
$before.revision = $after.revision
($before.initiatives | Where-Object id -eq 'orbit-video').brief = ($after.initiatives | Where-Object id -eq 'orbit-video').brief
if (($before | ConvertTo-Json -Depth 100 -Compress) -ne ($after | ConvertTo-Json -Depth 100 -Compress)) { throw 'Unexpected changes outside campaign brief and revision' }
Write-Output 'VERIFIED: exact campaign readback; all other records and campaign limits unchanged.'
Stop-Transcript
