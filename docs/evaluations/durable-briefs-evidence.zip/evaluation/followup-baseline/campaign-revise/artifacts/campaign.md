# A planet in one coffee break — revised synthetic campaign brief

## Audience and hypothesis
For relaxing-game fans who want a five-minute break. Showing the first action before its visible payoff may help viewers understand how to begin and encourage a first round. This is an untested demonstration hypothesis.

## Revised caption
Start with one small action. Watch a little world grow. Play a five-minute round.

Use the existing initiative-tagged try link with this caption. The destination URL is not supplied in this demo; retain the existing destination and attribution tags when preparing the asset.

## Capture outline
Plan one short gameplay capture, approximately 15–20 seconds. The asset is still to be produced.

1. Opening, roughly 0–5 seconds: begin on the real first-action screen. Keep the relevant control and pointer/touch input visible; demonstrate one complete first action before showing a finished planet. Use a brief overlay naming the exact action as it appears in the verified build. The demo mentions seed-choice confusion but does not establish the control label, input method, or recommended seed; confirm these during capture preparation rather than inventing them.
2. Immediate result, roughly 5–10 seconds: hold on the visible response to that same action, so a viewer can connect input and result. Avoid cutting away before the response is legible.
3. Payoff, roughly 10–15 seconds: reveal the little world's growth from that gameplay session. Label any time compression; do not imply a developed planet appears instantly from the first input.
4. Closing, roughly 15–20 seconds: hold the CTA, “Play a five-minute round,” with the existing tagged try link in the caption/description. Do not promise saving, return features, or mobile controls that have not been verified.

Preparation allocation within the existing one-hour cap: 10 minutes to verify the first action and link, 25 minutes to capture, 15 minutes to trim and caption, and 10 minutes to check input-before-result order and legibility. If this cannot be completed within the cap, pause the clip. Planning only; do not record, schedule, or publish as part of this revision.

## Measurement and attribution
Keep the existing initiative-tagged try link and attribution plan. Record attributed visitors and starts over the same reporting period, tied to orbit-video and YouTube. Preserve the existing definitions for historical comparisons; validate identity handling and the start event before interpreting a visitor-to-start ratio as person-level conversion. Inspect first-action completion and full-round completion separately in the already planned direct playtest; do not relabel starts as completed rounds.

The synthetic October 1–7 ledger contains 90 visitors and 8 starts (an observed count ratio of 8.9%), plus one return count. These are demonstration counts, not evidence of channel effectiveness or this revision's effect. The weekly and daily view series each total 2,400 and must not be added together. Reach alone is not success.

For future return measurement, separately define the cohort as unique new players with a verified first session attributed to orbit-video during October 1–14. Define a return as a distinct second session within seven days of each player's first session; report returned players divided by eligible players with a complete seven-day follow-up, plus the number still pending. This is a proposed measurement definition, not verified instrumentation. At the October 14 review, report only mature follow-up and mark later players pending; do not classify incomplete follow-up as non-return. The demo's single return is not an established 1/8 retention rate. The project objective remains learning whether 20 new players return for a second session.

Inspect with: `node scripts/marketing.mjs report --project orbit --initiative orbit-video --workspace .agent-marketing/brief-eval/followup-baseline/campaign-revise/workspace.json` and apply matching date filters to period comparisons. A future comparison would remain descriptive unless exposure and assignment support a causal comparison.

## Constraints and review decision
Owner: Family studio. Channel: YouTube. Campaign dates: October 1–14, 2026. Budget: 0 USD; no ad spend. Clip preparation cap: one hour, within the shared strategy's three maker-hours for the next test. CTA: “Play a five-minute round.” No publication is authorized.

Current decision: revise the planned asset to put the first action before the payoff, and hold distribution expansion while the first-use problem is investigated. No result from the revised asset exists yet.

Review the campaign on October 14, 2026. Use the three intended-player sessions already called for in the strategy and inspect whether players understand and complete the first action. Continue only if that condition is observed; if the same hesitation repeats, change the try path at that point rather than increasing reach. Pause the clip if support or preparation exceeds the cap. If observations or attribution checks are incomplete, record the decision as pending; do not call the revision successful from views. The shared strategy review remains October 15, 2026.

## Evidence and limits
Source: the saved Orbit Garden strategy, the existing orbit-video brief, and the supplied synthetic ledger. Placeholder evidence URL: https://example.com/demo-evidence. No external research or real player findings were added. Synthetic counts establish neither market demand, payment intent, nor a causal effect. A clearer clip may explain entry, but repeated hesitation in the actual game would require a separate try-path change; this revision does not implement that broader fix.
