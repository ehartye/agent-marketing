Revised **orbit-video** as a saved plan. Nothing was published.

**Caption**

> One small action. A little world begins to grow. See how a round starts in Orbit Garden, then play a five-minute round: [initiative-tagged try link]

**Capture outline — approximately 15 seconds**

1. **0–3s:** Show the real starting screen and first actionable control. If the build begins with seed selection, show that selection after verifying it.
2. **3–7s:** Show the actual input and immediate response, with the control/pointer visible and readable on a phone.
3. **7–12s:** Show the resulting growth. Label any elapsed gameplay; keep the first action before every payoff shot.
4. **12–15s:** Hold the result with the single CTA, **“Play a five-minute round.”** Use the same tagged try link in the caption/description.

Footage remains to be produced and checked against current product behavior. The fixture supplies no real try URL, so the link stays a placeholder until verified.

**Existing limits retained:** Family studio owns the campaign; dates remain October 1–14, 2026; budget remains **$0**; preparation remains capped at **one hour total**, including time already spent. Pause if support or preparation exceeds the cap. The larger project allowance does not increase this campaign's limit.

**Measurement:** Keep the initiative-tagged attribution plan, preserve existing destination queries and recovered tag values, and report attributed visitors and starts over matching windows. Record raw definitions, source, collection time and identity limitations. Keep views separate from product use. Observe whether intended players understand and complete the first action, then separately record full-round completion using the already planned player sessions. For returns, the brief defines a separate verified cohort of October 8–11 first-time starters returning in a distinct session within 72 hours; report missing identity or immature follow-up as unavailable. Do not reinterpret the synthetic one return as retention.

The demo's 90 visitors and 8 starts give an 8.9% observed ratio, not proof this revision works. No revised clip has been released, and no new outcomes were invented. The independent first-action experiment's existing stopping rule is unchanged.

**Review decision — October 14:** Change the planned clip now; keep distribution expansion on hold. Continue only when observed players understand and complete the first action within the existing limits. Change the try path if the same hesitation repeats. Pause if the cap is exceeded or the flow is broken; insufficient observations mean insufficient evidence, not success. A clearer clip may expose an onboarding problem without fixing it; any product change needs its own scope.

Run the saved-record report from the repository root:

```powershell
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/followup-with/campaign-revise/workspace.json
```

This command reports ledger records; it does not collect analytics. Full capture, attribution, measurement commands and review criteria are in [campaign.md](campaign.md).

Saved and read back at **revision 2**, initiative **orbit-video**, workspace `.agent-marketing/brief-eval/followup-with/campaign-revise/workspace.json`. Reopen through **Decide & plan → orbit-video → Read saved campaign brief**. Validation passed, and the saved text matches the artifact. Actual CLI commands and output are retained in [commands-output.txt](commands-output.txt), with the write/verification script in [apply-and-verify.ps1](apply-and-verify.ps1).
