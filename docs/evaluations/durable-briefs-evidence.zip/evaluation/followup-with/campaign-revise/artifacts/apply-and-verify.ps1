$evalDir = '.agent-marketing/brief-eval/followup-with/campaign-revise'
Start-Transcript -Path "$evalDir/artifacts/commands-output.txt" -Append
Write-Output 'COMMAND: node scripts/marketing.mjs utm https://example.com/REPLACE-WITH-VERIFIED-TRY-URL --source youtube --medium organic-video --campaign orbit-video --content first-action-before-payoff'
node scripts/marketing.mjs utm https://example.com/REPLACE-WITH-VERIFIED-TRY-URL --source youtube --medium organic-video --campaign orbit-video --content first-action-before-payoff
Write-Output 'COMMAND: node scripts/marketing.mjs import <artifacts/initiative-patch.json> --workspace <fixture> --revision 0'
node scripts/marketing.mjs import "$evalDir/artifacts/initiative-patch.json" --workspace "$evalDir/workspace.json" --revision 0
if ($LASTEXITCODE -ne 0) { throw 'Patch failed' }
Write-Output 'COMMAND: node scripts/marketing.mjs document save campaign orbit-video <artifacts/campaign.md> --workspace <fixture> --revision 1'
node scripts/marketing.mjs document save campaign orbit-video "$evalDir/artifacts/campaign.md" --workspace "$evalDir/workspace.json" --revision 1
if ($LASTEXITCODE -ne 0) { throw 'Save failed' }
Write-Output 'COMMAND: node scripts/marketing.mjs document show campaign orbit-video --workspace <fixture>'
node scripts/marketing.mjs document show campaign orbit-video --workspace "$evalDir/workspace.json"
Write-Output 'COMMAND: node scripts/marketing.mjs validate --workspace <fixture>'
node scripts/marketing.mjs validate --workspace "$evalDir/workspace.json"
$before = Get-Content "$evalDir/artifacts/workspace-before.json" -Raw | ConvertFrom-Json
$after = Get-Content "$evalDir/workspace.json" -Raw | ConvertFrom-Json
$saved = $after.initiatives | Where-Object id -eq 'orbit-video'
$expected = (Get-Content "$evalDir/artifacts/campaign.md" -Raw).Trim()
if ($saved.brief.markdown.Trim() -ne $expected) { throw 'Brief readback mismatch' }
foreach ($field in @('start','end','budget','owner','status','cta','id','projectId','channel','name')) {
  $prior = $before.initiatives | Where-Object id -eq 'orbit-video'
  if ($prior.$field -ne $saved.$field) { throw "Unexpected initiative change: $field" }
}
foreach ($field in @('projects','observations','reactions','competitors','experiments','evidence','sources')) {
 if (($before.$field | ConvertTo-Json -Depth 40 -Compress) -ne ($after.$field | ConvertTo-Json -Depth 40 -Compress)) { throw "Unexpected collection change: $field" }
}
Write-Output 'VERIFIED: saved brief matches artifact; initiative limits/status/CTA unchanged; other collections unchanged; revision 2.'
Stop-Transcript
