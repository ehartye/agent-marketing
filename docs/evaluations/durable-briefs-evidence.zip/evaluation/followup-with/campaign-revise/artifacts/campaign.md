# A planet in one coffee break — revised planning brief

Synthetic demo only. Initiative: orbit-video; project: orbit; channel: YouTube. No publication, capture, outreach or spending has been performed or authorized.

## Audience, rationale and hypothesis
Relaxing-game fans looking for a five-minute break. Hypothesis: showing the first action before its visible payoff helps intended players understand how to begin and complete a first round. The saved strategy prioritizes first-use understanding before more distribution. Synthetic reactions about seed choice and phone controls motivate this revision; they do not validate it. Source placeholder: https://example.com/demo-evidence. Product behavior remains to be verified during capture.

## Revised caption
One small action. A little world begins to grow. See how a round starts in Orbit Garden, then play a five-minute round: [initiative-tagged try link]

One CTA: Play a five-minute round. The five-minute positioning comes from the supplied project; do not claim guaranteed completion, saving, mobile compatibility or later-game features. Replace the link placeholder only after verifying the actual try destination.

## Capture outline — one short gameplay clip, approximately 15 seconds
1. 0–3 seconds: open on the actual starting state, with the first actionable control legible. No finished-world teaser before the action. If the current build starts with seed selection, show that selection; verify this rather than inventing a control or seed recommendation.
2. 3–7 seconds: show the real input and immediate response in sequence, with the pointer/touch indicator visible. Use the build's exact control label for any overlay. Keep enough context to let a viewer repeat the action.
3. 7–12 seconds: show the visible growth/payoff caused by that action. Any later progress must follow the action and be clearly labeled as elapsed gameplay; do not imply an immediate result that takes longer.
4. 12–15 seconds: hold on the result with “Play a five-minute round” and use the same tagged try link in the caption/description. No second CTA.

Asset status: capture outline only; footage still to be produced. Review at phone viewing size with sound off for legibility and action-before-payoff order. Before any eventual release, verify the link-to-first-action path on the intended device. Check the current build before answering seed-choice, phone-control or save/return questions; draft replies should name the verified control and supported behavior, never promise unverified features. Keep any support within the existing cap; no contact is authorized here.

## Limits retained
Owner: Family studio. Campaign dates: 2026-10-01 through 2026-10-14; review: 2026-10-14. Budget: 0 USD. Clip preparation cap: one hour total, not an extra hour per revision. Pause the clip if support or preparation exceeds the cap. Suggested allocation within remaining preparation time: 10 minutes confirm first action/try path, 25 capture, 15 trim/caption, 10 verify. Subtract time already spent; simplify or pause if insufficient. The project's three maker-hours/week and 300 USD budget do not enlarge this initiative's limits. Existing running status describes the fixture; this revised asset remains a plan.

## Attribution and measurement
Retain the initiative-tagged try link and matched-period visitors/starts reporting. No actual try URL or existing tag values are recorded in this fixture, so preserve any existing values when recovered rather than claiming to replace them. For a new revision-specific link, proposed values are source=youtube, medium=organic-video, campaign=orbit-video, content=first-action-before-payoff. The generated example URL is illustrative only. Keep the real destination's original queries; no UTM tags on internal navigation. Retain the original initiative ID and log the actual revision release time if release is later authorized. Until then there are no revised-clip results.

Primary useful outcome: observed intended players understand and complete the first action, with first-round completion recorded separately. Use the already planned three intended-player sessions; record unaided completion, hesitation, device and round completion without claiming these are representative. Do not add recruiting or increase project effort for this revision.

Keep raw platform views separate from product use. For new measurement, document visitors as distinct measured visitors arriving through the tagged entry and starts as those attributed visitors triggering the verified first-round-start event during the same reporting window, stating identity/deduplication limitations. Preserve native definitions, evidence source, period and collection time in every observation; do not relabel old fixture starts as completed rounds. Record observed round completion in the review evidence unless a verified event is available. Record actual spend and maker hours.

Return cohort, separately: once identity and instrumentation are verified, take attributed first-time starters from October 8–11 and measure the same players starting a distinct second session within 72 hours of their first start, through October 14. Report numerator, eligible denominator and exclusions; later starters are immature for this review. If no verified identity or revised release exists, report the cohort unavailable rather than treating the synthetic 1 return as a retention rate. Do not manufacture a cohort field for historical observations.

The supplied October 1–7 counts are synthetic: 90 visitors and 8 starts (8.9% observed ratio), 1 return with no verified cohort. They establish neither conversion improvement nor causal impact. The 2,400 aggregate views and daily series cover the same period and must not be added together. The separate first-action experiment retains its stopping rule: 100 assigned visitors per arm and a full seven-day window, with early stopping only for a broken flow. This clip revision is not an experiment win.

Runnable read-only measurement commands from the repository root:

```powershell
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-01 --to 2026-10-07 --workspace .agent-marketing/brief-eval/followup-with/campaign-revise/workspace.json
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/followup-with/campaign-revise/workspace.json
node scripts/marketing.mjs experiment orbit-first-action --workspace .agent-marketing/brief-eval/followup-with/campaign-revise/workspace.json
```

These report saved records; they do not collect new analytics. After a later authorized test, import only verified observations with their source definitions and compatible windows. No collection/publication is part of this task.

## Review decision — October 14, 2026
Current decision: change the planned clip to show the first action before its payoff; hold distribution expansion until first-use understanding is established. Synthetic data cannot justify scaling.

- Continue only if observed players understand and complete the first action and preparation/support remain within the cap. Continue means retain this direction for the next owner decision, not automatic publication, spend or extension beyond October 14.
- Change the try path if the same hesitation repeats; a clearer clip alone may not fix seed-choice or phone-control confusion. Record the repeated hesitation and propose one focused change; product edits are outside this planning task.
- Pause/stop the clip if support or preparation exceeds the cap, or the try path is broken. If observations are unavailable, report insufficient evidence and keep expansion on hold rather than declaring success.

Review actual maker time, spend, attributed starts, first-action/round observations, the eligible return cohort and unresolved objections. Keep the October 14 campaign decision distinct from the project's October 15 strategy review. Do not move the stopping rules after seeing results.
