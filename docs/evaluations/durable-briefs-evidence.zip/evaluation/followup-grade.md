# Fresh paired campaign-revision follow-up

**Both WITH and BASELINE pass all six criteria (6/6 each).** Both ledgers pass fresh native validation, both full saved briefs exactly match their campaign.md artifacts, and both preserve the original one-hour support/preparation stopping rule. The original grade.md and grade.json remain unchanged.

| Mode | C1 persistence | C2 usable/honest content | C3 task/limits | C4 preservation | C5 readback/location | C6 valid workflow | Total |
|---|---:|---:|---:|---:|---:|---:|---:|
| WITH | 1 | 1 | 1 | 1 | 1 | 1 | 6/6 |
| BASELINE | 1 | 1 | 1 | 1 | 1 | 1 | 6/6 |

## Constraint retention

The original source says “cap clip preparation at one hour” and “pause the clip if support or preparation exceeds the cap.”

WITH now explicitly retains: “Clip preparation cap: one hour total, not an extra hour per revision. Pause the clip if support or preparation exceeds the cap.” It also states that the project's three maker-hours and $300 budget do not enlarge initiative limits. This resolves the initial WITH revision's weakened support trigger.

BASELINE retains “Preparation allocation within the existing one-hour cap” and “Pause the clip if support or preparation exceeds the cap.” Its reference to fitting within the project's three maker-hours does not replace or enlarge the initiative cap. Both preserve owner, October 1–14 dates, October 14 review, $0 budget, CTA, tagged-link attribution and a separate return cohort.

Both provide conditional product-mechanics wording, a revised caption and clear first-action-before-payoff capture sequence. Both distinguish synthetic historical counts from unobserved revision results and define continue/change/pause decisions. Neither adds fabricated observations. WITH proposes a 72-hour return cohort and BASELINE seven days; the seed prescribed no return interval, so these qualified proposed definitions do not violate source constraints.

## Actual readback evidence

Both fresh cases now retain their executable save/verification scripts and transcript success output. WITH's artifacts/apply-and-verify.ps1 reloads workspace.json, selects orbit-video.brief.markdown, compares it to campaign.md and throws on mismatch. Its commands-output.txt records “VERIFIED: saved brief matches artifact; initiative limits/status/CTA unchanged; other collections unchanged; revision 2.”

BASELINE's artifacts/save-verify.ps1 performs the same saved-file comparison and checks for unrelated record changes. Its save-verify-output.txt records “VERIFIED: exact campaign readback; all other records and campaign limits unchanged.” Both responses identify the saved campaign/artifact location; WITH names the full workspace/UI route, and BASELINE supplies the artifact/script paths, with the full workspace in the brief's report command.

**Evidence limitation:** native CLI stdout is absent from these PowerShell transcripts. I am not treating the blank native-output sections as retained document-show JSON. C5 passes because actual scripts reload the saved content and their subsequent assertion-success output is retained. Both scripts trim text for comparison; my independent check confirms exact equality including whitespace. Initial BASELINE cases lacked the actual script and output, so this is a concrete evidence improvement under the same criterion.

## Native validation and preservation

Ran node scripts/marketing.mjs validate against both follow-up workspace files: WITH revision 2 and BASELINE revision 1 both return ok. Each has 2 projects, 3 initiatives, 15 observations, 6 reactions, 3 competitors, 2 experiments, 3 evidence and 0 sources. Full parsed seed comparison confirms all non-target records/documents are unchanged. WITH changes the target hypothesis and brief; BASELINE changes only the brief, in addition to workspace revisions.

WITH's documented revision-0 import followed by revision-1 document save is valid. BASELINE's revision-0 document save is valid. No publishing, outreach or spend commands appear. BASELINE documented recovered --help and Windows glob errors; they did not prevent successful save/readback. There are no unresolved operational failures or scored content weaknesses in this pair.

This is one fresh paired follow-up, not a superiority or safety proof. Both modes pass; the result does not establish that the added skill sentence caused the improvement or predict wider reliability. Full structured evidence is in [followup-grade.json](followup-grade.json).
