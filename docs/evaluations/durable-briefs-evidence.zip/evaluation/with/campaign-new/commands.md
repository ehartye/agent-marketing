# Actual commands and results

Development invocation was explicitly permitted; no managed runtime installation was run. Node v24.18.0. Read local named SKILL.md, craft references, docs/CLI.md, setup and (for campaigns) collateral instructions.

```text
node scripts/marketing.mjs help --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "name": "marketing",
  "version": "0.1.0",
  "workspace": "--workspace <file> (default .agent-marketing/workspace.json)",
  "commands": [
    "init",
    "demo",
    "validate",
    "import <json-or-csv>",
    "put <collection> <record.json>",
    "document save <strategy|campaign> <record-id> <brief.md> --revision n",
    "document show <strategy|campaign> <record-id>",
    "document export <strategy|campaign> <record-id> [--out brief.md]",
    "report [--project id --initiative id --from date --to date]",
    "advise <project-id>",
    "channels [project-id]",
    "experiment <experiment-id>",
    "utm <url> --source x --medium y --campaign z [--content c]",
    "monitor [--source id]",
    "serve [--port 4318]",
    "export [--format json|csv] [--out file]",
    "rules [topic]",
    "help"
  ]
}
```

```text
node scripts/marketing.mjs rules measurement --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
[
  {
    "id": "attribution-not-causality",
    "topic": "measurement",
    "kind": "external",
    "rule": "Tagged visits and attributed conversions do not prove incremental causal effects.",
    "referenceIds": [
      "measurement",
      "causality"
    ]
  },
  {
    "id": "reach-is-not-people",
    "topic": "measurement",
    "kind": "derived",
    "rule": "Do not sum platform reach into unique people without deduplicated identities and permission to use them.",
    "referenceIds": [
      "ga4-schema",
      "github-traffic"
    ],
    "reason": "Repeated visitors and overlapping platform audiences violate distinct-person addition."
  },
  {
    "id": "definitions-and-windows",
    "topic": "measurement",
    "kind": "external",
    "rule": "Preserve raw metric definition, period, source and collection time; compare only compatible reporting scopes.",
    "referenceIds": [
      "youtube",
      "ga4-schema",
      "github-traffic"
    ]
  }
]
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 0,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-new\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 0,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
    "updatedAt": "2026-10-08T12:00:00.000Z"
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit"
  },
  "uniqueReach": null,
  "totals": [
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "views",
      "value": 2400,
      "evidence": [
        "orbit-views"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "definition": "visitors",
      "value": 90,
      "evidence": [
        "orbit-visitors"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "definition": "starts",
      "value": 8,
      "evidence": [
        "orbit-starts"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "definition": "returns",
      "value": 1,
      "evidence": [
        "orbit-returns"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "definition": "cost",
      "currency": "USD",
      "value": 0,
      "evidence": [
        "orbit-cost"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "YouTube playback starts (daily demo)",
      "value": 2400,
      "evidence": [
        "orbit-daily-2026-10-01",
        "orbit-daily-2026-10-02",
        "orbit-daily-2026-10-03",
        "orbit-daily-2026-10-04",
        "orbit-daily-2026-10-05",
        "orbit-daily-2026-10-06",
        "orbit-daily-2026-10-07"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-01",
          "kind": "period"
        },
        {
          "start": "2026-10-02",
          "end": "2026-10-02",
          "kind": "period"
        },
        {
          "start": "2026-10-03",
          "end": "2026-10-03",
          "kind": "period"
        },
        {
          "start": "2026-10-04",
          "end": "2026-10-04",
          "kind": "period"
        },
        {
          "start": "2026-10-05",
          "end": "2026-10-05",
          "kind": "period"
        },
        {
          "start": "2026-10-06",
          "end": "2026-10-06",
          "kind": "period"
        },
        {
          "start": "2026-10-07",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    }
  ],
  "sentiment": {
    "positive": 2,
    "negative": 0,
    "neutral": 0,
    "mixed": 1,
    "unknown": 0,
    "unreviewed": 2
  },
  "funnels": [
    {
      "channel": "youtube",
      "initiativeId": "orbit-video",
      "visitors": 90,
      "starts": 8,
      "rate": 0.08888888888888889,
      "evidence": [
        "orbit-visitors",
        "orbit-starts"
      ],
      "interpretation": "Observed ratio; counts may represent different people"
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "name": "First action: label versus animated hint",
      "arms": [
        {
          "name": "A · text label",
          "interval": {
            "rate": 0.16666666666666666,
            "low": 0.05836576805861446,
            "high": 0.39222038103915724,
            "trials": 18,
            "successes": 3
          }
        },
        {
          "name": "B · animated hint",
          "interval": {
            "rate": 0.23809523809523808,
            "low": 0.10628013022636468,
            "high": 0.4509117368295075,
            "trials": 21,
            "successes": 5
          }
        }
      ],
      "difference": {
        "low": -0.28594025081279256,
        "high": 0.3925459687708931,
        "estimate": 0.07142857142857142
      },
      "decision": "collect",
      "ready": false,
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "caveat": "Conservative interval from separate Wilson bounds, not a calibrated hypothesis test. Prespecify duration, allocation and stopping; no causal winner from nonrandom groups or repeated peeking."
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": [],
  "warnings": [
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

```text
node scripts/marketing.mjs document show campaign orbit-playtest --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 2
{"error":{"code":"E_COMMAND","message":"No campaign document saved for orbit-playtest"}}
```

```text
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-new/initiative-patch.json --revision 0 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "schema": "marketing/workspace@1",
  "revision": 1,
  "projects": [
    {
      "id": "orbit",
      "name": "Orbit Garden · demo",
      "audience": [
        "indie players",
        "relaxing-game fans"
      ],
      "category": "game",
      "problem": "A relaxing five-minute break",
      "promise": "Grow a little world in five minutes",
      "stage": "beta",
      "objective": "Learn whether 20 new players return for a second session",
      "weeklyHours": 3,
      "budget": 300,
      "currency": "USD",
      "strategy": {
        "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "sketch",
      "name": "Sketch Relay · demo",
      "audience": [
        "developers",
        "creative makers"
      ],
      "category": "tool",
      "problem": "Sharing a quick UI idea takes too long",
      "promise": "Turn a rough sketch into a runnable interaction",
      "stage": "prototype",
      "objective": "Observe five successful first-use sessions",
      "weeklyHours": 2,
      "budget": 50,
      "currency": "USD"
    }
  ],
  "initiatives": [
    {
      "id": "orbit-video",
      "projectId": "orbit",
      "name": "A planet in one coffee break",
      "channel": "youtube",
      "hypothesis": "A clip of the payoff brings players who try a full round",
      "cta": "Play a five-minute round",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio",
      "brief": {
        "markdown": "# A planet in one coffee break — synthetic campaign brief\n\n## Audience and hypothesis\nFor relaxing-game fans: a short clip of growing a tiny planet will bring players who complete a first round. This is a demonstration hypothesis, not a validated result.\n\n## Message, asset and CTA\nDraft caption: Grow a little world in five minutes. Show the first action and its visible payoff in a short gameplay capture. Asset: capture still to be produced. CTA: Play a five-minute round. No publication is authorized by this sample.\n\n## Measurement\nUse an initiative-tagged try link. Record attributed visitors and starts over the same period, plus a separately defined return cohort. Reach alone is not success. Inspect with: marketing report --project orbit --initiative orbit-video --workspace <ledger>.\n\n## Constraints and review\nOwner: Family studio. Dates: 2026-10-01 through 2026-10-14. Budget: 0 USD; cap clip preparation at one hour. Review on 2026-10-14. Continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause the clip if support or preparation exceeds the cap.\n\n## Evidence and limits\nRead the saved Orbit Garden strategy for the shared rationale. Demo source: https://example.com/demo-evidence. Synthetic counts do not establish channel effectiveness, payment intent or a causal effect.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "orbit-playtest",
      "projectId": "orbit",
      "name": "First round playtest",
      "channel": "direct",
      "hypothesis": "Observing three unchanged first sessions reveals repeated first-action hesitation that prevents unaided completion",
      "cta": "Try a round and describe where you hesitate",
      "status": "planned",
      "start": "2026-10-09",
      "end": "2026-10-15",
      "budget": 0,
      "owner": "Family studio"
    },
    {
      "id": "sketch-github",
      "projectId": "sketch",
      "name": "A working example worth cloning",
      "channel": "github",
      "hypothesis": "A short runnable example activates developers better than feature lists",
      "cta": "Run the starter example",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio"
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-visitors",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "visitors",
      "value": 62,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-starts",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "starts",
      "value": 18,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-stars",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "stars",
      "value": 41,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "snapshot",
      "definition": "stars",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "series": "sketch-stars"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r6",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "text": "Useful example. I needed clearer setup instructions.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "installation"
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    },
    {
      "id": "sketch-substitute",
      "projectId": "sketch",
      "name": "Screenshot plus chat message",
      "kind": "substitute",
      "positioning": "Already available and easy to share, but cannot demonstrate interaction",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "projectId": "orbit",
      "name": "First action: label versus animated hint",
      "hypothesis": "A visible hint improves first-round starts",
      "primaryMetric": "Unique assigned visitors completing a first round within one session",
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · text label",
          "trials": 18,
          "successes": 3
        },
        {
          "name": "B · animated hint",
          "trials": 21,
          "successes": 5
        }
      ]
    },
    {
      "id": "sketch-install",
      "projectId": "sketch",
      "name": "Runnable README example versus feature list",
      "hypothesis": "A runnable example improves first successful setup",
      "primaryMetric": "Assigned developers successfully running the example",
      "stoppingRule": "Compare after 100 unique assigned visitors per arm over a full two-week window; report failures separately",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · feature list",
          "trials": 100,
          "successes": 11
        },
        {
          "name": "B · example",
          "trials": 100,
          "successes": 39
        }
      ]
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "sketch-problem",
      "projectId": "sketch",
      "dimension": "problem",
      "claim": "Three synthetic maker interviews describe a recent need for a runnable sketch",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": []
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 1,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document save campaign orbit-playtest .agent-marketing/brief-eval/with/campaign-new/campaign.md --revision 1 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-new\\workspace.json",
  "kind": "campaign",
  "id": "orbit-playtest",
  "projectId": "orbit",
  "name": "First round playtest",
  "revision": 2,
  "location": "initiatives[id=orbit-playtest].brief",
  "document": {
    "markdown": "# Orbit Garden: three first-time sessions\n\nInitiative: orbit-playtest. Channel: direct, owner-arranged in-person observation. Owner: Family studio. Status: planned. Dates: 9–15 October 2026; review 15 October. Budget: USD 0. Total maker-time cap: 180 minutes, including recruitment, preparation, sessions, support and review. Planning only: no one has been contacted and no session has occurred.\n\n## Audience, rationale and hypothesis\n\nThree first-time players who already enjoy relaxing games. Preserve the project strategy: prioritize first use before increasing distribution; the visual payoff may bring interest but is not a validated channel result. The synthetic workspace has 90 visitors/eight starts, a seed-choice hesitation, and an unreviewed mobile-control complaint. These suggest questions, not real evidence of a defect. Its example.com source is a placeholder. The existing experiment remains independent; three qualitative sessions cannot determine its winning variant or retention.\n\nHypothesis: observing the unchanged opening will reveal whether a repeated first-action hesitation prevents unaided completion. Test the opening first; do not silently change the build during these three sessions. Assumptions: a playable build and three willing intended players can be made available within the cap. The supplied records contain no real try URL, device support list or contacts. Those are execution prerequisites, not invented facts.\n\n## Draft message and one CTA\n\n“Do you enjoy relaxing games and have about 20 minutes to try something new? We're checking whether Orbit Garden's opening makes sense for a first-time player. It's a beta about growing a little world in a short round. You don't need to be good at games, and we're testing the game, not you. We'll watch where the opening is clear or confusing and take notes; you can stop whenever you want. **Try a round and describe where you hesitate.** [Owner-supplied working try link]”\n\nThis is an owner-review draft, not a sent invitation. Do not include testimonials, participant identities, a save feature, pricing, or mobile compatibility claims. Verify the actual build matches the stated premise before using the draft.\n\n## Preparation, session outline and support\n\nAllocate 25 minutes to test the URL/build on the participant's device, confirm a first round is reachable, check first-use event capture, and reset prior progress. Allow 20 minutes for owner-run scheduling and consent, 60 for three 20-minute sessions, 35 for synthesis, 20 for a single clarification proposal, and 20 buffer. Do not add clip production or grow reach this week.\n\nEach 20-minute session:\n1. Minutes 0–3: explain notes and voluntary participation; confirm no prior play and intended-audience fit. Use anonymous P1/P2/P3 identifiers. Obtain separate permission before recording media; written notes alone suffice.\n2. Minutes 3–10: open the same build. Say “Try a round; tell me what you're thinking.” Observe without an instructional demo. Note first action/time, hesitation and any error. Let the player stop; after 60 seconds stuck, ask “What would you expect to do?” Record that prompt as assistance.\n3. Minutes 10–15: allow completion or end the attempt. Mark unaided versus assisted completion distinctly. A completed round after help is not an unaided success.\n4. Minutes 15–18: ask what was confusing and what they expected next, including whether another session interests them. Do not lead them toward praise.\n5. Minutes 18–20: thank them, note issues and confirm any optional follow-up permission. No commitment to a feature or follow-up contact is implied.\n\nSupport drafts: “Where did you expect to act?” for confusion; “Let's stop and record the device/build issue” for a broken flow; “I'll record that question; I haven't verified save/return behavior” for a save question. Stop if distressed or unwilling; do not push completion.\n\n## Measurement and attribution\n\nPrimary: number of these three eligible first-time participants who both perform the first action and complete the first round without help during the session. Also retain separate first-action success and completion fields so the bottleneck remains visible. Raw sheet columns: anonymous ID, eligibility, consent, date, device/browser, build, initial URL/UTMs, session start/end, first action/time, exact hesitation, assistance/time, round completed/time, unaided success, errors, optional follow-up consent, observer minutes. Blank means unknown, not zero.\n\nUse a verified owner URL before execution. Placeholder for exercising the CLI only: https://example.com/orbit?build=beta . Tag source=direct, medium=playtest, campaign=orbit-playtest, content=first-session. Preserve the build query. Keep tags off internal navigation. UTM parameters label referral traffic; they do not collect product events or prove causality. [Google's campaign URL guidance](https://support.google.com/analytics/answer/10917952?hl=en), checked 8 October 2026.\n\nFor a future real import, visitors means distinct eligible session participants who loaded the tagged build during 9–15 October; starts means those completing the first meaningful action, once per participant; store unaided completion numerator/denominator in a companion session summary rather than pretending the schema has a new metric. Record hours as actual maker hours and cost as actual USD spend. Source each aggregate to an owner-controlled notes/export URL; preserve definition, window and collectedAt. Import no planned counts. Returns remain a separate opted-in cohort: same consenting participant, a second session within seven days of first session; review after each window matures, by 22 October. Do not mix this cohort with the historical synthetic return.\n\nRunnable CLI templates (from repository root; replace the placeholder URL before use):\n```powershell\nnode scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source direct --medium playtest --campaign orbit-playtest --content first-session --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\nnode scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\nnode scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-new/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json --revision CURRENT_REVISION\nnode scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\n```\nThe import is for future actual records; that file does not yet exist. Read validation's revision immediately before import, reconcile if stale, and never overwrite the saved brief with a partial initiative record.\n\n## Continue/change/stop, fixed before observation\n\nContinue to consider one small distribution test if all three complete unaided and the try path works. Change one first-use element and repeat observation if at least two share a hesitation; one isolated issue warrants targeted follow-up, not a claimed general defect. Stop this session/test on a broken flow, participant withdrawal, or 180 minutes used. If fewer than three attend, report insufficient evidence and review scheduling; do not substitute invented zeros. No outcome warrants scaling or declaring causality from three participants.\n\nNext action: verify the actual build URL and prepare the blank session sheet. Missing participants/build can delay execution; the planning brief and stable initiative remain usable without pretending those prerequisites are satisfied.\n",
    "updatedAt": "2026-10-08T19:09:41.181Z"
  }
}
```

```text
node scripts/marketing.mjs document show campaign orbit-playtest --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-new\\workspace.json",
  "kind": "campaign",
  "id": "orbit-playtest",
  "projectId": "orbit",
  "name": "First round playtest",
  "revision": 2,
  "location": "initiatives[id=orbit-playtest].brief",
  "document": {
    "markdown": "# Orbit Garden: three first-time sessions\n\nInitiative: orbit-playtest. Channel: direct, owner-arranged in-person observation. Owner: Family studio. Status: planned. Dates: 9–15 October 2026; review 15 October. Budget: USD 0. Total maker-time cap: 180 minutes, including recruitment, preparation, sessions, support and review. Planning only: no one has been contacted and no session has occurred.\n\n## Audience, rationale and hypothesis\n\nThree first-time players who already enjoy relaxing games. Preserve the project strategy: prioritize first use before increasing distribution; the visual payoff may bring interest but is not a validated channel result. The synthetic workspace has 90 visitors/eight starts, a seed-choice hesitation, and an unreviewed mobile-control complaint. These suggest questions, not real evidence of a defect. Its example.com source is a placeholder. The existing experiment remains independent; three qualitative sessions cannot determine its winning variant or retention.\n\nHypothesis: observing the unchanged opening will reveal whether a repeated first-action hesitation prevents unaided completion. Test the opening first; do not silently change the build during these three sessions. Assumptions: a playable build and three willing intended players can be made available within the cap. The supplied records contain no real try URL, device support list or contacts. Those are execution prerequisites, not invented facts.\n\n## Draft message and one CTA\n\n“Do you enjoy relaxing games and have about 20 minutes to try something new? We're checking whether Orbit Garden's opening makes sense for a first-time player. It's a beta about growing a little world in a short round. You don't need to be good at games, and we're testing the game, not you. We'll watch where the opening is clear or confusing and take notes; you can stop whenever you want. **Try a round and describe where you hesitate.** [Owner-supplied working try link]”\n\nThis is an owner-review draft, not a sent invitation. Do not include testimonials, participant identities, a save feature, pricing, or mobile compatibility claims. Verify the actual build matches the stated premise before using the draft.\n\n## Preparation, session outline and support\n\nAllocate 25 minutes to test the URL/build on the participant's device, confirm a first round is reachable, check first-use event capture, and reset prior progress. Allow 20 minutes for owner-run scheduling and consent, 60 for three 20-minute sessions, 35 for synthesis, 20 for a single clarification proposal, and 20 buffer. Do not add clip production or grow reach this week.\n\nEach 20-minute session:\n1. Minutes 0–3: explain notes and voluntary participation; confirm no prior play and intended-audience fit. Use anonymous P1/P2/P3 identifiers. Obtain separate permission before recording media; written notes alone suffice.\n2. Minutes 3–10: open the same build. Say “Try a round; tell me what you're thinking.” Observe without an instructional demo. Note first action/time, hesitation and any error. Let the player stop; after 60 seconds stuck, ask “What would you expect to do?” Record that prompt as assistance.\n3. Minutes 10–15: allow completion or end the attempt. Mark unaided versus assisted completion distinctly. A completed round after help is not an unaided success.\n4. Minutes 15–18: ask what was confusing and what they expected next, including whether another session interests them. Do not lead them toward praise.\n5. Minutes 18–20: thank them, note issues and confirm any optional follow-up permission. No commitment to a feature or follow-up contact is implied.\n\nSupport drafts: “Where did you expect to act?” for confusion; “Let's stop and record the device/build issue” for a broken flow; “I'll record that question; I haven't verified save/return behavior” for a save question. Stop if distressed or unwilling; do not push completion.\n\n## Measurement and attribution\n\nPrimary: number of these three eligible first-time participants who both perform the first action and complete the first round without help during the session. Also retain separate first-action success and completion fields so the bottleneck remains visible. Raw sheet columns: anonymous ID, eligibility, consent, date, device/browser, build, initial URL/UTMs, session start/end, first action/time, exact hesitation, assistance/time, round completed/time, unaided success, errors, optional follow-up consent, observer minutes. Blank means unknown, not zero.\n\nUse a verified owner URL before execution. Placeholder for exercising the CLI only: https://example.com/orbit?build=beta . Tag source=direct, medium=playtest, campaign=orbit-playtest, content=first-session. Preserve the build query. Keep tags off internal navigation. UTM parameters label referral traffic; they do not collect product events or prove causality. [Google's campaign URL guidance](https://support.google.com/analytics/answer/10917952?hl=en), checked 8 October 2026.\n\nFor a future real import, visitors means distinct eligible session participants who loaded the tagged build during 9–15 October; starts means those completing the first meaningful action, once per participant; store unaided completion numerator/denominator in a companion session summary rather than pretending the schema has a new metric. Record hours as actual maker hours and cost as actual USD spend. Source each aggregate to an owner-controlled notes/export URL; preserve definition, window and collectedAt. Import no planned counts. Returns remain a separate opted-in cohort: same consenting participant, a second session within seven days of first session; review after each window matures, by 22 October. Do not mix this cohort with the historical synthetic return.\n\nRunnable CLI templates (from repository root; replace the placeholder URL before use):\n```powershell\nnode scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source direct --medium playtest --campaign orbit-playtest --content first-session --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\nnode scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\nnode scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-new/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json --revision CURRENT_REVISION\nnode scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json\n```\nThe import is for future actual records; that file does not yet exist. Read validation's revision immediately before import, reconcile if stale, and never overwrite the saved brief with a partial initiative record.\n\n## Continue/change/stop, fixed before observation\n\nContinue to consider one small distribution test if all three complete unaided and the try path works. Change one first-use element and repeat observation if at least two share a hesitation; one isolated issue warrants targeted follow-up, not a claimed general defect. Stop this session/test on a broken flow, participant withdrawal, or 180 minutes used. If fewer than three attend, report insufficient evidence and review scheduling; do not substitute invented zeros. No outcome warrants scaling or declaring causality from three participants.\n\nNext action: verify the actual build URL and prepare the blank session sheet. Missing participants/build can delay execution; the planning brief and stable initiative remain usable without pretending those prerequisites are satisfied.\n",
    "updatedAt": "2026-10-08T19:09:41.181Z"
  }
}
```

```text
node scripts/marketing.mjs utm https://example.com/orbit?build=beta --source direct --medium playtest --campaign orbit-playtest --content first-session --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "url": "https://example.com/orbit?build=beta&utm_source=direct&utm_medium=playtest&utm_campaign=orbit-playtest&utm_content=first-session"
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 2,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit",
    "initiativeId": "orbit-playtest",
    "from": "2026-10-09",
    "to": "2026-10-15"
  },
  "uniqueReach": null,
  "totals": [],
  "observations": [],
  "reactions": [],
  "sentiment": {
    "positive": 0,
    "negative": 0,
    "neutral": 0,
    "mixed": 0,
    "unknown": 0,
    "unreviewed": 0
  },
  "funnels": [],
  "experiments": [],
  "competitors": [],
  "evidence": [],
  "sources": [],
  "warnings": [
    "Only observations fully contained in the date filter are included; period totals cannot be prorated.",
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

Readback equality: PASS. All prior record IDs retained; observations, reactions, competitors, experiments, evidence and sources byte-equivalent as parsed values. Final revision 2. No execution outcomes inserted.
