# Orbit Garden: three first-time sessions

Initiative: orbit-playtest. Channel: direct, owner-arranged in-person observation. Owner: Family studio. Status: planned. Dates: 9–15 October 2026; review 15 October. Budget: USD 0. Total maker-time cap: 180 minutes, including recruitment, preparation, sessions, support and review. Planning only: no one has been contacted and no session has occurred.

## Audience, rationale and hypothesis

Three first-time players who already enjoy relaxing games. Preserve the project strategy: prioritize first use before increasing distribution; the visual payoff may bring interest but is not a validated channel result. The synthetic workspace has 90 visitors/eight starts, a seed-choice hesitation, and an unreviewed mobile-control complaint. These suggest questions, not real evidence of a defect. Its example.com source is a placeholder. The existing experiment remains independent; three qualitative sessions cannot determine its winning variant or retention.

Hypothesis: observing the unchanged opening will reveal whether a repeated first-action hesitation prevents unaided completion. Test the opening first; do not silently change the build during these three sessions. Assumptions: a playable build and three willing intended players can be made available within the cap. The supplied records contain no real try URL, device support list or contacts. Those are execution prerequisites, not invented facts.

## Draft message and one CTA

“Do you enjoy relaxing games and have about 20 minutes to try something new? We're checking whether Orbit Garden's opening makes sense for a first-time player. It's a beta about growing a little world in a short round. You don't need to be good at games, and we're testing the game, not you. We'll watch where the opening is clear or confusing and take notes; you can stop whenever you want. **Try a round and describe where you hesitate.** [Owner-supplied working try link]”

This is an owner-review draft, not a sent invitation. Do not include testimonials, participant identities, a save feature, pricing, or mobile compatibility claims. Verify the actual build matches the stated premise before using the draft.

## Preparation, session outline and support

Allocate 25 minutes to test the URL/build on the participant's device, confirm a first round is reachable, check first-use event capture, and reset prior progress. Allow 20 minutes for owner-run scheduling and consent, 60 for three 20-minute sessions, 35 for synthesis, 20 for a single clarification proposal, and 20 buffer. Do not add clip production or grow reach this week.

Each 20-minute session:
1. Minutes 0–3: explain notes and voluntary participation; confirm no prior play and intended-audience fit. Use anonymous P1/P2/P3 identifiers. Obtain separate permission before recording media; written notes alone suffice.
2. Minutes 3–10: open the same build. Say “Try a round; tell me what you're thinking.” Observe without an instructional demo. Note first action/time, hesitation and any error. Let the player stop; after 60 seconds stuck, ask “What would you expect to do?” Record that prompt as assistance.
3. Minutes 10–15: allow completion or end the attempt. Mark unaided versus assisted completion distinctly. A completed round after help is not an unaided success.
4. Minutes 15–18: ask what was confusing and what they expected next, including whether another session interests them. Do not lead them toward praise.
5. Minutes 18–20: thank them, note issues and confirm any optional follow-up permission. No commitment to a feature or follow-up contact is implied.

Support drafts: “Where did you expect to act?” for confusion; “Let's stop and record the device/build issue” for a broken flow; “I'll record that question; I haven't verified save/return behavior” for a save question. Stop if distressed or unwilling; do not push completion.

## Measurement and attribution

Primary: number of these three eligible first-time participants who both perform the first action and complete the first round without help during the session. Also retain separate first-action success and completion fields so the bottleneck remains visible. Raw sheet columns: anonymous ID, eligibility, consent, date, device/browser, build, initial URL/UTMs, session start/end, first action/time, exact hesitation, assistance/time, round completed/time, unaided success, errors, optional follow-up consent, observer minutes. Blank means unknown, not zero.

Use a verified owner URL before execution. Placeholder for exercising the CLI only: https://example.com/orbit?build=beta . Tag source=direct, medium=playtest, campaign=orbit-playtest, content=first-session. Preserve the build query. Keep tags off internal navigation. UTM parameters label referral traffic; they do not collect product events or prove causality. [Google's campaign URL guidance](https://support.google.com/analytics/answer/10917952?hl=en), checked 8 October 2026.

For a future real import, visitors means distinct eligible session participants who loaded the tagged build during 9–15 October; starts means those completing the first meaningful action, once per participant; store unaided completion numerator/denominator in a companion session summary rather than pretending the schema has a new metric. Record hours as actual maker hours and cost as actual USD spend. Source each aggregate to an owner-controlled notes/export URL; preserve definition, window and collectedAt. Import no planned counts. Returns remain a separate opted-in cohort: same consenting participant, a second session within seven days of first session; review after each window matures, by 22 October. Do not mix this cohort with the historical synthetic return.

Runnable CLI templates (from repository root; replace the placeholder URL before use):
```powershell
node scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source direct --medium playtest --campaign orbit-playtest --content first-session --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-new/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json --revision CURRENT_REVISION
node scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/campaign-new/workspace.json
```
The import is for future actual records; that file does not yet exist. Read validation's revision immediately before import, reconcile if stale, and never overwrite the saved brief with a partial initiative record.

## Continue/change/stop, fixed before observation

Continue to consider one small distribution test if all three complete unaided and the try path works. Change one first-use element and repeat observation if at least two share a hesitation; one isolated issue warrants targeted follow-up, not a claimed general defect. Stop this session/test on a broken flow, participant withdrawal, or 180 minutes used. If fewer than three attend, report insufficient evidence and review scheduling; do not substitute invented zeros. No outcome warrants scaling or declaring causality from three participants.

Next action: verify the actual build URL and prepare the blank session sheet. Missing participants/build can delay execution; the planning brief and stable initiative remain usable without pretending those prerequisites are satisfied.
