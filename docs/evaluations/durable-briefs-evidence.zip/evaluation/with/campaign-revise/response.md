# Final user response

Revised and saved **orbit-video** so the capture starts with the actual first action, shows its response, then the little-world payoff and one CTA.

Caption: “Start small. Watch the first move, then see the little world it grows into. Orbit Garden is a relaxing game for a short break. **Play a five-minute round:** [verified, initiative-tagged try link].”

Preserved Family studio ownership, 1–14 October dates, **USD 0 and one-hour preparation cap**, initiative attribution, matched visitor/start windows and a separate return cohort. Review **14 October**: continue only with observed comprehension and first-action completion; repeated hesitation changes the try path; excess preparation/support or a broken path pauses the asset. No publication occurred. The saved brief includes the capture timings, measurement commands and readiness checks; actual footage and a real try URL are not supplied.

Workspace: .agent-marketing/brief-eval/with/campaign-revise/workspace.json. Reopen **Decide & plan → orbit-video → Read saved campaign brief**.

Full saved deliverable: [campaign.md](campaign.md).

# Execution notes

Existing saved documents were read before revision. All writes, readbacks and final validations succeeded. No global runtime installation, external posting, spending, outreach or wiki/product-file edits were performed. Development CLI invocation was explicitly authorized.


Sources checked with web tool on 2026-10-08: https://support.google.com/youtube/answer/2801973?hl=en (spam/deceptive promotion); https://support.google.com/youtube/answer/13748639?hl=en (clickable link surfaces); https://support.google.com/analytics/answer/10917952?hl=en (UTM campaign/content parameters). Published rules constrain execution; channel choice and numeric review criteria are planning inferences.

# Full saved deliverable

# A planet in one coffee break — action before payoff

Revision dated 8 October 2026; synthetic planning workspace. Initiative orbit-video, channel youtube, owner Family studio. Preserve existing dates 1–14 October, status running as a historical ledger state, USD 0 budget, preparation cap one hour, review 14 October. No publication or contact is performed. Revised asset remains a draft. Preserve the shared strategy's priority: observe first use before increasing reach.

## Audience and revised hypothesis

Relaxing-game fans who want a short break. Preserve the original payoff hypothesis; refine it: showing the actual first action before the tiny-world payoff may set clearer expectations and bring players who understand and complete a round. Synthetic counts of 90 visitors/eight starts and the seed-choice comment are illustrative leads only. The mobile-control comment is unreviewed. No claim of improvement, causality, retention or actual audience demand follows from these records. https://example.com/demo-evidence is a placeholder, not live proof.

## Revised caption

“Start small. Watch the first move, then see the little world it grows into. Orbit Garden is a relaxing game for a short break. **Play a five-minute round:** [verified, initiative-tagged try link].”

Caption is conditional on the actual capture showing that progression. “Five-minute round” retains the existing promise and CTA; time a real round before publication. Avoid claiming instant payoff, automatic saving or mobile support. No factual specification beyond the supplied concept is invented.

## Capture outline and one-hour preparation cap

Use actual current-build gameplay, with no mocked controls. The exact gesture/seed is not known from the ledger: verify it before capture, then show it accurately.

1. 0–4 seconds: show the initial playable state and the real first action with the pointer/touch indicator visible. Keep the relevant control readable at the intended viewing size. Text: “The first move.”
2. 4–12 seconds: show the immediate response and next moment of the same run. Do not splice in a different successful build.
3. 12–22 seconds: show the small world's visible payoff. If time is compressed, label the acceleration; do not imply this all happens immediately.
4. 22–28 seconds: hold the result and display the single CTA: “Play a five-minute round.” Put the verified tagged URL on a surface viewers can use.

Preparation allocation: 10 minutes verifying build/try path, 20 capture, 15 simple edit/caption, 10 attribution and readability checks, 5 buffer. Stop or pause if preparation exceeds 60 minutes. Fit response/review work within the project's three-hour weekly cap and prioritize its planned first-use sessions; this draft does not authorize an extra three-hour campaign. If the schedule has no room, defer capture/publication rather than displacing those sessions. No capture file is claimed to exist.

## Try path and support

No actual game URL was supplied. Before use, replace the example URL, check that it opens the intended beta and reaches the first action on the intended device, and verify analytics or an agreed manual observation route. Answer “Which seed?” with the actual tested control, not a guessed instruction. For a broken phone flow, collect device/build detail and pause the link if broadly broken. For saving, state only verified current behavior; the synthetic request is not a feature guarantee.

For a future regular video, verify clickable-description eligibility. [YouTube's link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments have non-clickable URLs and long-form external links require advanced features. If choosing a Short later, adapt the CTA to the verified profile/related-video route and document the extra attribution step. [YouTube spam policy](https://support.google.com/youtube/answer/2801973?hl=en) prohibits deceptive metadata and repetitive spam. Checked 8 October 2026. These sources constrain execution; they do not validate the campaign hypothesis.

## Preserve attribution; clarify measurement

Keep initiative-tagged referral tracking, matched windows for visitors/starts, and a separately defined return cohort. No previously fixed UTM values were stored; use source=youtube, medium=organic-video, campaign=orbit-video, content=first-action-v2 for this new asset, retaining any original destination query. The example URL below is a placeholder. Record the actual future publication time and compare only its post-publication window; do not credit the new draft with the historical 1–7 October numbers. Do not rewrite the historical rows or mix daily and weekly view totals.

Raw records: video ID, build, publication time, tagged URL, native views and definition, unique tagged visitors, first-action starts, observed unaided first actions/completed rounds, assistance and repeated confusion, support minutes, actual cost. Visitors: distinct consenting or appropriately deduplicated users arriving via this exact link within the same reporting window. Starts: those visitors completing the first meaningful action, once each. Primary useful outcome: observed unaided first-round completion, numerator/eligible observed players kept in a companion summary; clicks/views are supporting attention. Existing generic starts cannot retroactively be treated as completions.

Return cohort: verified first-time starters attributable to this asset, second product session within seven days of first use. Review it only once those windows mature, up to 21 October for starts on 14 October. Do not infer retention from the old single synthetic return. [Google's UTM guidance](https://support.google.com/analytics/answer/10917952?hl=en) supports consistent campaign/content tags, not causal claims.

```powershell
node scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source youtube --medium organic-video --campaign orbit-video --content first-action-v2 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-revise/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json --revision CURRENT_REVISION
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
```
The import template is for future verified data; no actual-observations.json is created and no outcomes are entered now. Replace CURRENT_REVISION with validate's result immediately before import; reconcile conflicts. No internal navigation tags.

## Decision on 14 October

Preserve existing criteria: continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause if preparation/support exceeds capacity. Operationalize this review as three observed intended-player sessions: all three understand and complete the first action unaided permits continuing one bounded test; two sharing a hesitation triggers one try-path change before further reach. One isolated issue calls for targeted observation. Fewer than three is insufficient evidence, not success or failure. A broken try path or exceeded one-hour preparation cap stops the revised asset. With publication still unauthorized, the current decision is keep the asset in draft and prepare first-action footage only within available time. The later review can record readiness without inventing campaign performance.


# Actual commands and results

Development invocation was explicitly permitted; no managed runtime installation was run. Node v24.18.0. Read local named SKILL.md, craft references, docs/CLI.md, setup and (for campaigns) collateral instructions.

```text
node scripts/marketing.mjs help --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "name": "marketing",
  "version": "0.1.0",
  "workspace": "--workspace <file> (default .agent-marketing/workspace.json)",
  "commands": [
    "init",
    "demo",
    "validate",
    "import <json-or-csv>",
    "put <collection> <record.json>",
    "document save <strategy|campaign> <record-id> <brief.md> --revision n",
    "document show <strategy|campaign> <record-id>",
    "document export <strategy|campaign> <record-id> [--out brief.md]",
    "report [--project id --initiative id --from date --to date]",
    "advise <project-id>",
    "channels [project-id]",
    "experiment <experiment-id>",
    "utm <url> --source x --medium y --campaign z [--content c]",
    "monitor [--source id]",
    "serve [--port 4318]",
    "export [--format json|csv] [--out file]",
    "rules [topic]",
    "help"
  ]
}
```

```text
node scripts/marketing.mjs rules measurement --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
[
  {
    "id": "attribution-not-causality",
    "topic": "measurement",
    "kind": "external",
    "rule": "Tagged visits and attributed conversions do not prove incremental causal effects.",
    "referenceIds": [
      "measurement",
      "causality"
    ]
  },
  {
    "id": "reach-is-not-people",
    "topic": "measurement",
    "kind": "derived",
    "rule": "Do not sum platform reach into unique people without deduplicated identities and permission to use them.",
    "referenceIds": [
      "ga4-schema",
      "github-traffic"
    ],
    "reason": "Repeated visitors and overlapping platform audiences violate distinct-person addition."
  },
  {
    "id": "definitions-and-windows",
    "topic": "measurement",
    "kind": "external",
    "rule": "Preserve raw metric definition, period, source and collection time; compare only compatible reporting scopes.",
    "referenceIds": [
      "youtube",
      "ga4-schema",
      "github-traffic"
    ]
  }
]
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 0,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-revise\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 0,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
    "updatedAt": "2026-10-08T12:00:00.000Z"
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit"
  },
  "uniqueReach": null,
  "totals": [
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "views",
      "value": 2400,
      "evidence": [
        "orbit-views"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "definition": "visitors",
      "value": 90,
      "evidence": [
        "orbit-visitors"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "definition": "starts",
      "value": 8,
      "evidence": [
        "orbit-starts"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "definition": "returns",
      "value": 1,
      "evidence": [
        "orbit-returns"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "definition": "cost",
      "currency": "USD",
      "value": 0,
      "evidence": [
        "orbit-cost"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "YouTube playback starts (daily demo)",
      "value": 2400,
      "evidence": [
        "orbit-daily-2026-10-01",
        "orbit-daily-2026-10-02",
        "orbit-daily-2026-10-03",
        "orbit-daily-2026-10-04",
        "orbit-daily-2026-10-05",
        "orbit-daily-2026-10-06",
        "orbit-daily-2026-10-07"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-01",
          "kind": "period"
        },
        {
          "start": "2026-10-02",
          "end": "2026-10-02",
          "kind": "period"
        },
        {
          "start": "2026-10-03",
          "end": "2026-10-03",
          "kind": "period"
        },
        {
          "start": "2026-10-04",
          "end": "2026-10-04",
          "kind": "period"
        },
        {
          "start": "2026-10-05",
          "end": "2026-10-05",
          "kind": "period"
        },
        {
          "start": "2026-10-06",
          "end": "2026-10-06",
          "kind": "period"
        },
        {
          "start": "2026-10-07",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    }
  ],
  "sentiment": {
    "positive": 2,
    "negative": 0,
    "neutral": 0,
    "mixed": 1,
    "unknown": 0,
    "unreviewed": 2
  },
  "funnels": [
    {
      "channel": "youtube",
      "initiativeId": "orbit-video",
      "visitors": 90,
      "starts": 8,
      "rate": 0.08888888888888889,
      "evidence": [
        "orbit-visitors",
        "orbit-starts"
      ],
      "interpretation": "Observed ratio; counts may represent different people"
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "name": "First action: label versus animated hint",
      "arms": [
        {
          "name": "A · text label",
          "interval": {
            "rate": 0.16666666666666666,
            "low": 0.05836576805861446,
            "high": 0.39222038103915724,
            "trials": 18,
            "successes": 3
          }
        },
        {
          "name": "B · animated hint",
          "interval": {
            "rate": 0.23809523809523808,
            "low": 0.10628013022636468,
            "high": 0.4509117368295075,
            "trials": 21,
            "successes": 5
          }
        }
      ],
      "difference": {
        "low": -0.28594025081279256,
        "high": 0.3925459687708931,
        "estimate": 0.07142857142857142
      },
      "decision": "collect",
      "ready": false,
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "caveat": "Conservative interval from separate Wilson bounds, not a calibrated hypothesis test. Prespecify duration, allocation and stopping; no causal winner from nonrandom groups or repeated peeking."
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": [],
  "warnings": [
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

```text
node scripts/marketing.mjs document show campaign orbit-video --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-revise\\workspace.json",
  "kind": "campaign",
  "id": "orbit-video",
  "projectId": "orbit",
  "name": "A planet in one coffee break",
  "revision": 0,
  "location": "initiatives[id=orbit-video].brief",
  "document": {
    "markdown": "# A planet in one coffee break — synthetic campaign brief\n\n## Audience and hypothesis\nFor relaxing-game fans: a short clip of growing a tiny planet will bring players who complete a first round. This is a demonstration hypothesis, not a validated result.\n\n## Message, asset and CTA\nDraft caption: Grow a little world in five minutes. Show the first action and its visible payoff in a short gameplay capture. Asset: capture still to be produced. CTA: Play a five-minute round. No publication is authorized by this sample.\n\n## Measurement\nUse an initiative-tagged try link. Record attributed visitors and starts over the same period, plus a separately defined return cohort. Reach alone is not success. Inspect with: marketing report --project orbit --initiative orbit-video --workspace <ledger>.\n\n## Constraints and review\nOwner: Family studio. Dates: 2026-10-01 through 2026-10-14. Budget: 0 USD; cap clip preparation at one hour. Review on 2026-10-14. Continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause the clip if support or preparation exceeds the cap.\n\n## Evidence and limits\nRead the saved Orbit Garden strategy for the shared rationale. Demo source: https://example.com/demo-evidence. Synthetic counts do not establish channel effectiveness, payment intent or a causal effect.\n",
    "updatedAt": "2026-10-08T12:00:00.000Z"
  }
}
```

```text
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-revise/initiative-patch.json --revision 0 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "schema": "marketing/workspace@1",
  "revision": 1,
  "projects": [
    {
      "id": "orbit",
      "name": "Orbit Garden · demo",
      "audience": [
        "indie players",
        "relaxing-game fans"
      ],
      "category": "game",
      "problem": "A relaxing five-minute break",
      "promise": "Grow a little world in five minutes",
      "stage": "beta",
      "objective": "Learn whether 20 new players return for a second session",
      "weeklyHours": 3,
      "budget": 300,
      "currency": "USD",
      "strategy": {
        "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "sketch",
      "name": "Sketch Relay · demo",
      "audience": [
        "developers",
        "creative makers"
      ],
      "category": "tool",
      "problem": "Sharing a quick UI idea takes too long",
      "promise": "Turn a rough sketch into a runnable interaction",
      "stage": "prototype",
      "objective": "Observe five successful first-use sessions",
      "weeklyHours": 2,
      "budget": 50,
      "currency": "USD"
    }
  ],
  "initiatives": [
    {
      "id": "orbit-video",
      "projectId": "orbit",
      "name": "A planet in one coffee break",
      "channel": "youtube",
      "hypothesis": "Showing the actual first action before the payoff helps intended players understand and complete a round",
      "cta": "Play a five-minute round",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio",
      "brief": {
        "markdown": "# A planet in one coffee break — synthetic campaign brief\n\n## Audience and hypothesis\nFor relaxing-game fans: a short clip of growing a tiny planet will bring players who complete a first round. This is a demonstration hypothesis, not a validated result.\n\n## Message, asset and CTA\nDraft caption: Grow a little world in five minutes. Show the first action and its visible payoff in a short gameplay capture. Asset: capture still to be produced. CTA: Play a five-minute round. No publication is authorized by this sample.\n\n## Measurement\nUse an initiative-tagged try link. Record attributed visitors and starts over the same period, plus a separately defined return cohort. Reach alone is not success. Inspect with: marketing report --project orbit --initiative orbit-video --workspace <ledger>.\n\n## Constraints and review\nOwner: Family studio. Dates: 2026-10-01 through 2026-10-14. Budget: 0 USD; cap clip preparation at one hour. Review on 2026-10-14. Continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause the clip if support or preparation exceeds the cap.\n\n## Evidence and limits\nRead the saved Orbit Garden strategy for the shared rationale. Demo source: https://example.com/demo-evidence. Synthetic counts do not establish channel effectiveness, payment intent or a causal effect.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "orbit-playtest",
      "projectId": "orbit",
      "name": "First round playtest",
      "channel": "direct",
      "hypothesis": "A clearer first action improves successful starts",
      "cta": "Try a round and describe where you hesitate",
      "status": "planned",
      "start": "2026-10-09",
      "end": "2026-10-15",
      "budget": 0,
      "owner": "Family studio"
    },
    {
      "id": "sketch-github",
      "projectId": "sketch",
      "name": "A working example worth cloning",
      "channel": "github",
      "hypothesis": "A short runnable example activates developers better than feature lists",
      "cta": "Run the starter example",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio"
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-visitors",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "visitors",
      "value": 62,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-starts",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "starts",
      "value": 18,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-stars",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "stars",
      "value": 41,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "snapshot",
      "definition": "stars",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "series": "sketch-stars"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r6",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "text": "Useful example. I needed clearer setup instructions.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "installation"
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    },
    {
      "id": "sketch-substitute",
      "projectId": "sketch",
      "name": "Screenshot plus chat message",
      "kind": "substitute",
      "positioning": "Already available and easy to share, but cannot demonstrate interaction",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "projectId": "orbit",
      "name": "First action: label versus animated hint",
      "hypothesis": "A visible hint improves first-round starts",
      "primaryMetric": "Unique assigned visitors completing a first round within one session",
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · text label",
          "trials": 18,
          "successes": 3
        },
        {
          "name": "B · animated hint",
          "trials": 21,
          "successes": 5
        }
      ]
    },
    {
      "id": "sketch-install",
      "projectId": "sketch",
      "name": "Runnable README example versus feature list",
      "hypothesis": "A runnable example improves first successful setup",
      "primaryMetric": "Assigned developers successfully running the example",
      "stoppingRule": "Compare after 100 unique assigned visitors per arm over a full two-week window; report failures separately",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · feature list",
          "trials": 100,
          "successes": 11
        },
        {
          "name": "B · example",
          "trials": 100,
          "successes": 39
        }
      ]
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "sketch-problem",
      "projectId": "sketch",
      "dimension": "problem",
      "claim": "Three synthetic maker interviews describe a recent need for a runnable sketch",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": []
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 1,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document save campaign orbit-video .agent-marketing/brief-eval/with/campaign-revise/campaign.md --revision 1 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-revise\\workspace.json",
  "kind": "campaign",
  "id": "orbit-video",
  "projectId": "orbit",
  "name": "A planet in one coffee break",
  "revision": 2,
  "location": "initiatives[id=orbit-video].brief",
  "document": {
    "markdown": "# A planet in one coffee break — action before payoff\n\nRevision dated 8 October 2026; synthetic planning workspace. Initiative orbit-video, channel youtube, owner Family studio. Preserve existing dates 1–14 October, status running as a historical ledger state, USD 0 budget, preparation cap one hour, review 14 October. No publication or contact is performed. Revised asset remains a draft. Preserve the shared strategy's priority: observe first use before increasing reach.\n\n## Audience and revised hypothesis\n\nRelaxing-game fans who want a short break. Preserve the original payoff hypothesis; refine it: showing the actual first action before the tiny-world payoff may set clearer expectations and bring players who understand and complete a round. Synthetic counts of 90 visitors/eight starts and the seed-choice comment are illustrative leads only. The mobile-control comment is unreviewed. No claim of improvement, causality, retention or actual audience demand follows from these records. https://example.com/demo-evidence is a placeholder, not live proof.\n\n## Revised caption\n\n“Start small. Watch the first move, then see the little world it grows into. Orbit Garden is a relaxing game for a short break. **Play a five-minute round:** [verified, initiative-tagged try link].”\n\nCaption is conditional on the actual capture showing that progression. “Five-minute round” retains the existing promise and CTA; time a real round before publication. Avoid claiming instant payoff, automatic saving or mobile support. No factual specification beyond the supplied concept is invented.\n\n## Capture outline and one-hour preparation cap\n\nUse actual current-build gameplay, with no mocked controls. The exact gesture/seed is not known from the ledger: verify it before capture, then show it accurately.\n\n1. 0–4 seconds: show the initial playable state and the real first action with the pointer/touch indicator visible. Keep the relevant control readable at the intended viewing size. Text: “The first move.”\n2. 4–12 seconds: show the immediate response and next moment of the same run. Do not splice in a different successful build.\n3. 12–22 seconds: show the small world's visible payoff. If time is compressed, label the acceleration; do not imply this all happens immediately.\n4. 22–28 seconds: hold the result and display the single CTA: “Play a five-minute round.” Put the verified tagged URL on a surface viewers can use.\n\nPreparation allocation: 10 minutes verifying build/try path, 20 capture, 15 simple edit/caption, 10 attribution and readability checks, 5 buffer. Stop or pause if preparation exceeds 60 minutes. Fit response/review work within the project's three-hour weekly cap and prioritize its planned first-use sessions; this draft does not authorize an extra three-hour campaign. If the schedule has no room, defer capture/publication rather than displacing those sessions. No capture file is claimed to exist.\n\n## Try path and support\n\nNo actual game URL was supplied. Before use, replace the example URL, check that it opens the intended beta and reaches the first action on the intended device, and verify analytics or an agreed manual observation route. Answer “Which seed?” with the actual tested control, not a guessed instruction. For a broken phone flow, collect device/build detail and pause the link if broadly broken. For saving, state only verified current behavior; the synthetic request is not a feature guarantee.\n\nFor a future regular video, verify clickable-description eligibility. [YouTube's link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments have non-clickable URLs and long-form external links require advanced features. If choosing a Short later, adapt the CTA to the verified profile/related-video route and document the extra attribution step. [YouTube spam policy](https://support.google.com/youtube/answer/2801973?hl=en) prohibits deceptive metadata and repetitive spam. Checked 8 October 2026. These sources constrain execution; they do not validate the campaign hypothesis.\n\n## Preserve attribution; clarify measurement\n\nKeep initiative-tagged referral tracking, matched windows for visitors/starts, and a separately defined return cohort. No previously fixed UTM values were stored; use source=youtube, medium=organic-video, campaign=orbit-video, content=first-action-v2 for this new asset, retaining any original destination query. The example URL below is a placeholder. Record the actual future publication time and compare only its post-publication window; do not credit the new draft with the historical 1–7 October numbers. Do not rewrite the historical rows or mix daily and weekly view totals.\n\nRaw records: video ID, build, publication time, tagged URL, native views and definition, unique tagged visitors, first-action starts, observed unaided first actions/completed rounds, assistance and repeated confusion, support minutes, actual cost. Visitors: distinct consenting or appropriately deduplicated users arriving via this exact link within the same reporting window. Starts: those visitors completing the first meaningful action, once each. Primary useful outcome: observed unaided first-round completion, numerator/eligible observed players kept in a companion summary; clicks/views are supporting attention. Existing generic starts cannot retroactively be treated as completions.\n\nReturn cohort: verified first-time starters attributable to this asset, second product session within seven days of first use. Review it only once those windows mature, up to 21 October for starts on 14 October. Do not infer retention from the old single synthetic return. [Google's UTM guidance](https://support.google.com/analytics/answer/10917952?hl=en) supports consistent campaign/content tags, not causal claims.\n\n```powershell\nnode scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source youtube --medium organic-video --campaign orbit-video --content first-action-v2 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\nnode scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\nnode scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-revise/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json --revision CURRENT_REVISION\nnode scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\n```\nThe import template is for future verified data; no actual-observations.json is created and no outcomes are entered now. Replace CURRENT_REVISION with validate's result immediately before import; reconcile conflicts. No internal navigation tags.\n\n## Decision on 14 October\n\nPreserve existing criteria: continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause if preparation/support exceeds capacity. Operationalize this review as three observed intended-player sessions: all three understand and complete the first action unaided permits continuing one bounded test; two sharing a hesitation triggers one try-path change before further reach. One isolated issue calls for targeted observation. Fewer than three is insufficient evidence, not success or failure. A broken try path or exceeded one-hour preparation cap stops the revised asset. With publication still unauthorized, the current decision is keep the asset in draft and prepare first-action footage only within available time. The later review can record readiness without inventing campaign performance.\n",
    "updatedAt": "2026-10-08T19:09:41.651Z"
  }
}
```

```text
node scripts/marketing.mjs document show campaign orbit-video --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\campaign-revise\\workspace.json",
  "kind": "campaign",
  "id": "orbit-video",
  "projectId": "orbit",
  "name": "A planet in one coffee break",
  "revision": 2,
  "location": "initiatives[id=orbit-video].brief",
  "document": {
    "markdown": "# A planet in one coffee break — action before payoff\n\nRevision dated 8 October 2026; synthetic planning workspace. Initiative orbit-video, channel youtube, owner Family studio. Preserve existing dates 1–14 October, status running as a historical ledger state, USD 0 budget, preparation cap one hour, review 14 October. No publication or contact is performed. Revised asset remains a draft. Preserve the shared strategy's priority: observe first use before increasing reach.\n\n## Audience and revised hypothesis\n\nRelaxing-game fans who want a short break. Preserve the original payoff hypothesis; refine it: showing the actual first action before the tiny-world payoff may set clearer expectations and bring players who understand and complete a round. Synthetic counts of 90 visitors/eight starts and the seed-choice comment are illustrative leads only. The mobile-control comment is unreviewed. No claim of improvement, causality, retention or actual audience demand follows from these records. https://example.com/demo-evidence is a placeholder, not live proof.\n\n## Revised caption\n\n“Start small. Watch the first move, then see the little world it grows into. Orbit Garden is a relaxing game for a short break. **Play a five-minute round:** [verified, initiative-tagged try link].”\n\nCaption is conditional on the actual capture showing that progression. “Five-minute round” retains the existing promise and CTA; time a real round before publication. Avoid claiming instant payoff, automatic saving or mobile support. No factual specification beyond the supplied concept is invented.\n\n## Capture outline and one-hour preparation cap\n\nUse actual current-build gameplay, with no mocked controls. The exact gesture/seed is not known from the ledger: verify it before capture, then show it accurately.\n\n1. 0–4 seconds: show the initial playable state and the real first action with the pointer/touch indicator visible. Keep the relevant control readable at the intended viewing size. Text: “The first move.”\n2. 4–12 seconds: show the immediate response and next moment of the same run. Do not splice in a different successful build.\n3. 12–22 seconds: show the small world's visible payoff. If time is compressed, label the acceleration; do not imply this all happens immediately.\n4. 22–28 seconds: hold the result and display the single CTA: “Play a five-minute round.” Put the verified tagged URL on a surface viewers can use.\n\nPreparation allocation: 10 minutes verifying build/try path, 20 capture, 15 simple edit/caption, 10 attribution and readability checks, 5 buffer. Stop or pause if preparation exceeds 60 minutes. Fit response/review work within the project's three-hour weekly cap and prioritize its planned first-use sessions; this draft does not authorize an extra three-hour campaign. If the schedule has no room, defer capture/publication rather than displacing those sessions. No capture file is claimed to exist.\n\n## Try path and support\n\nNo actual game URL was supplied. Before use, replace the example URL, check that it opens the intended beta and reaches the first action on the intended device, and verify analytics or an agreed manual observation route. Answer “Which seed?” with the actual tested control, not a guessed instruction. For a broken phone flow, collect device/build detail and pause the link if broadly broken. For saving, state only verified current behavior; the synthetic request is not a feature guarantee.\n\nFor a future regular video, verify clickable-description eligibility. [YouTube's link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments have non-clickable URLs and long-form external links require advanced features. If choosing a Short later, adapt the CTA to the verified profile/related-video route and document the extra attribution step. [YouTube spam policy](https://support.google.com/youtube/answer/2801973?hl=en) prohibits deceptive metadata and repetitive spam. Checked 8 October 2026. These sources constrain execution; they do not validate the campaign hypothesis.\n\n## Preserve attribution; clarify measurement\n\nKeep initiative-tagged referral tracking, matched windows for visitors/starts, and a separately defined return cohort. No previously fixed UTM values were stored; use source=youtube, medium=organic-video, campaign=orbit-video, content=first-action-v2 for this new asset, retaining any original destination query. The example URL below is a placeholder. Record the actual future publication time and compare only its post-publication window; do not credit the new draft with the historical 1–7 October numbers. Do not rewrite the historical rows or mix daily and weekly view totals.\n\nRaw records: video ID, build, publication time, tagged URL, native views and definition, unique tagged visitors, first-action starts, observed unaided first actions/completed rounds, assistance and repeated confusion, support minutes, actual cost. Visitors: distinct consenting or appropriately deduplicated users arriving via this exact link within the same reporting window. Starts: those visitors completing the first meaningful action, once each. Primary useful outcome: observed unaided first-round completion, numerator/eligible observed players kept in a companion summary; clicks/views are supporting attention. Existing generic starts cannot retroactively be treated as completions.\n\nReturn cohort: verified first-time starters attributable to this asset, second product session within seven days of first use. Review it only once those windows mature, up to 21 October for starts on 14 October. Do not infer retention from the old single synthetic return. [Google's UTM guidance](https://support.google.com/analytics/answer/10917952?hl=en) supports consistent campaign/content tags, not causal claims.\n\n```powershell\nnode scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source youtube --medium organic-video --campaign orbit-video --content first-action-v2 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\nnode scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\nnode scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-revise/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json --revision CURRENT_REVISION\nnode scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json\n```\nThe import template is for future verified data; no actual-observations.json is created and no outcomes are entered now. Replace CURRENT_REVISION with validate's result immediately before import; reconcile conflicts. No internal navigation tags.\n\n## Decision on 14 October\n\nPreserve existing criteria: continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause if preparation/support exceeds capacity. Operationalize this review as three observed intended-player sessions: all three understand and complete the first action unaided permits continuing one bounded test; two sharing a hesitation triggers one try-path change before further reach. One isolated issue calls for targeted observation. Fewer than three is insufficient evidence, not success or failure. A broken try path or exceeded one-hour preparation cap stops the revised asset. With publication still unauthorized, the current decision is keep the asset in draft and prepare first-action footage only within available time. The later review can record readiness without inventing campaign performance.\n",
    "updatedAt": "2026-10-08T19:09:41.651Z"
  }
}
```

```text
node scripts/marketing.mjs utm https://example.com/orbit?build=beta --source youtube --medium organic-video --campaign orbit-video --content first-action-v2 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "url": "https://example.com/orbit?build=beta&utm_source=youtube&utm_medium=organic-video&utm_campaign=orbit-video&utm_content=first-action-v2"
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 2,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-09 --to 2026-10-14 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit",
    "initiativeId": "orbit-video",
    "from": "2026-10-09",
    "to": "2026-10-14"
  },
  "uniqueReach": null,
  "totals": [],
  "observations": [],
  "reactions": [],
  "sentiment": {
    "positive": 0,
    "negative": 0,
    "neutral": 0,
    "mixed": 0,
    "unknown": 0,
    "unreviewed": 0
  },
  "funnels": [],
  "experiments": [],
  "competitors": [],
  "evidence": [],
  "sources": [],
  "warnings": [
    "Only observations fully contained in the date filter are included; period totals cannot be prorated.",
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

Readback equality: PASS. All prior record IDs retained; observations, reactions, competitors, experiments, evidence and sources byte-equivalent as parsed values. Final revision 2. No execution outcomes inserted.
