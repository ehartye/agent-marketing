# A planet in one coffee break — action before payoff

Revision dated 8 October 2026; synthetic planning workspace. Initiative orbit-video, channel youtube, owner Family studio. Preserve existing dates 1–14 October, status running as a historical ledger state, USD 0 budget, preparation cap one hour, review 14 October. No publication or contact is performed. Revised asset remains a draft. Preserve the shared strategy's priority: observe first use before increasing reach.

## Audience and revised hypothesis

Relaxing-game fans who want a short break. Preserve the original payoff hypothesis; refine it: showing the actual first action before the tiny-world payoff may set clearer expectations and bring players who understand and complete a round. Synthetic counts of 90 visitors/eight starts and the seed-choice comment are illustrative leads only. The mobile-control comment is unreviewed. No claim of improvement, causality, retention or actual audience demand follows from these records. https://example.com/demo-evidence is a placeholder, not live proof.

## Revised caption

“Start small. Watch the first move, then see the little world it grows into. Orbit Garden is a relaxing game for a short break. **Play a five-minute round:** [verified, initiative-tagged try link].”

Caption is conditional on the actual capture showing that progression. “Five-minute round” retains the existing promise and CTA; time a real round before publication. Avoid claiming instant payoff, automatic saving or mobile support. No factual specification beyond the supplied concept is invented.

## Capture outline and one-hour preparation cap

Use actual current-build gameplay, with no mocked controls. The exact gesture/seed is not known from the ledger: verify it before capture, then show it accurately.

1. 0–4 seconds: show the initial playable state and the real first action with the pointer/touch indicator visible. Keep the relevant control readable at the intended viewing size. Text: “The first move.”
2. 4–12 seconds: show the immediate response and next moment of the same run. Do not splice in a different successful build.
3. 12–22 seconds: show the small world's visible payoff. If time is compressed, label the acceleration; do not imply this all happens immediately.
4. 22–28 seconds: hold the result and display the single CTA: “Play a five-minute round.” Put the verified tagged URL on a surface viewers can use.

Preparation allocation: 10 minutes verifying build/try path, 20 capture, 15 simple edit/caption, 10 attribution and readability checks, 5 buffer. Stop or pause if preparation exceeds 60 minutes. Fit response/review work within the project's three-hour weekly cap and prioritize its planned first-use sessions; this draft does not authorize an extra three-hour campaign. If the schedule has no room, defer capture/publication rather than displacing those sessions. No capture file is claimed to exist.

## Try path and support

No actual game URL was supplied. Before use, replace the example URL, check that it opens the intended beta and reaches the first action on the intended device, and verify analytics or an agreed manual observation route. Answer “Which seed?” with the actual tested control, not a guessed instruction. For a broken phone flow, collect device/build detail and pause the link if broadly broken. For saving, state only verified current behavior; the synthetic request is not a feature guarantee.

For a future regular video, verify clickable-description eligibility. [YouTube's link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments have non-clickable URLs and long-form external links require advanced features. If choosing a Short later, adapt the CTA to the verified profile/related-video route and document the extra attribution step. [YouTube spam policy](https://support.google.com/youtube/answer/2801973?hl=en) prohibits deceptive metadata and repetitive spam. Checked 8 October 2026. These sources constrain execution; they do not validate the campaign hypothesis.

## Preserve attribution; clarify measurement

Keep initiative-tagged referral tracking, matched windows for visitors/starts, and a separately defined return cohort. No previously fixed UTM values were stored; use source=youtube, medium=organic-video, campaign=orbit-video, content=first-action-v2 for this new asset, retaining any original destination query. The example URL below is a placeholder. Record the actual future publication time and compare only its post-publication window; do not credit the new draft with the historical 1–7 October numbers. Do not rewrite the historical rows or mix daily and weekly view totals.

Raw records: video ID, build, publication time, tagged URL, native views and definition, unique tagged visitors, first-action starts, observed unaided first actions/completed rounds, assistance and repeated confusion, support minutes, actual cost. Visitors: distinct consenting or appropriately deduplicated users arriving via this exact link within the same reporting window. Starts: those visitors completing the first meaningful action, once each. Primary useful outcome: observed unaided first-round completion, numerator/eligible observed players kept in a companion summary; clicks/views are supporting attention. Existing generic starts cannot retroactively be treated as completions.

Return cohort: verified first-time starters attributable to this asset, second product session within seven days of first use. Review it only once those windows mature, up to 21 October for starts on 14 October. Do not infer retention from the old single synthetic return. [Google's UTM guidance](https://support.google.com/analytics/answer/10917952?hl=en) supports consistent campaign/content tags, not causal claims.

```powershell
node scripts/marketing.mjs utm 'https://example.com/orbit?build=beta' --source youtube --medium organic-video --campaign orbit-video --content first-action-v2 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/campaign-revise/actual-observations.json --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json --revision CURRENT_REVISION
node scripts/marketing.mjs report --project orbit --initiative orbit-video --from 2026-10-08 --to 2026-10-14 --workspace .agent-marketing/brief-eval/with/campaign-revise/workspace.json
```
The import template is for future verified data; no actual-observations.json is created and no outcomes are entered now. Replace CURRENT_REVISION with validate's result immediately before import; reconcile conflicts. No internal navigation tags.

## Decision on 14 October

Preserve existing criteria: continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause if preparation/support exceeds capacity. Operationalize this review as three observed intended-player sessions: all three understand and complete the first action unaided permits continuing one bounded test; two sharing a hesitation triggers one try-path change before further reach. One isolated issue calls for targeted observation. Fewer than three is insufficient evidence, not success or failure. A broken try path or exceeded one-hour preparation cap stops the revised asset. With publication still unauthorized, the current decision is keep the asset in draft and prepare first-action footage only within available time. The later review can record readiness without inventing campaign performance.
