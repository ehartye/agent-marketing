# Orbit Garden strategy — revised 8 October 2026

Retain the existing audience and promise: relaxing-game fans seeking a five-minute break, growing a little world in one short round. Retain the visible-payoff hypothesis, the existing YouTube discovery test as historical context, and the requirement for a defined return cohort. The change is operational: pause increasing reach, including orbit-video, and make three direct first sessions the only active planned work for 9–15 October. Owner: Family studio; three maker-hours and USD 0 this week.

## Reasoning preserved and limits

The saved strategy's 90 visitors and eight starts are synthetic illustrations of a first-use question, not market demand. The workspace also includes a reviewed seed-choice hesitation and an unreviewed mobile-control complaint. Review the latter as a lead, not a verified diagnosis. The example source https://example.com/demo-evidence is not live proof. Do not calculate retention from the one return without verified identities/window. Do not add overlapping daily and weekly view rows. The existing randomized hint test remains under its own target; these qualitative sessions do not replace its stopping rule.

Assume neither three available participants nor a working try URL: check both before execution. Direct means owner-arranged in-person observation; no social platform, community permission or email list is assumed. The planning record authorizes no contact. Reddit remains the prior strategy's conditional alternative, outside the initiatives ledger until a specific community, its audience, platform rules and local posting permission have been verified.

## Choices and tradeoffs

| Choice | Time/lag | Spending/risk | Complexity/best practice | Maintainability |
|---|---|---|---|---|
| Direct three-session test now | 180 minutes total; same-session feedback, scheduling may slip | USD 0; three people are a convenience sample, coaching can bias behavior | Low setup; test an unchanged build and record behavior before prompting | Short notes and a bounded review; no standing moderation work |
| Continue increasing YouTube reach now | At least an hour of production plus response/review; plays may take days | USD 0 organic but risks spending scarce time on traffic before first use works | Existing channel is convenient; truthful gameplay and attribution still needed | Ongoing comments/support compete with observation time; paused |
| YouTube as sustainable follow-up | Reuse one gameplay capture in a later week, no cadence promise | USD 0; selection and attribution uncertainty persist | Already represented in ledger; show action then payoff and one try CTA | Maintain link and answer questions within the next week's cap |

CLI channel ranking is a planning heuristic only. [Current YouTube rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive metadata and spam; [link guidance](https://support.google.com/youtube/answer/13748639?hl=en) distinguishes non-clickable Shorts URLs from long-form links requiring advanced features. Checked 8 October 2026. These support a possible later execution format, not a claim that YouTube will perform best. Direct in-person observation does not require a community posting route.

## Audience → message → asset → CTA → measurement

Audience: three first-time players who enjoy relaxing games. Draft message: “We're checking whether Orbit Garden's opening is clear. Try a short round and describe where you hesitate.” Asset: unchanged current build and a blank session sheet. CTA: “Try a round and describe where you hesitate.” Do not prime them with an instructional clip. Record build/device, first visible action and time, exact hesitation, assistance, first-round completion, and voluntary interest in another session. A request to save is not an implemented save feature.

Time: 25 minutes build/device checks, 20 scheduling/consent, three 20-minute sessions, 35 synthesis, 20 drafting a single clarification proposal, 20 buffer = 180. No extra clip production this week. If availability fails, spend no more than the scheduling allocation and flag insufficient evidence. Keep orbit-playtest planned, direct, 9–15 October, budget 0; retain the paused video and all historical data. Product changes wait for observed evidence and separate implementation work.

## Review: 15 October 2026

Count unaided first actions and completed rounds separately out of three. All three completing without help permits considering a bounded YouTube follow-up; it does not demonstrate conversion or retention. A shared hesitation in at least two means change one first-use element and retest before increasing reach. One isolated issue gets a targeted follow-up; fewer than three sessions is insufficient evidence. Stop on a broken build or the three-hour cap.

Revisit the channel choice if the opening is clear but a subsequent tagged YouTube test attracts players outside the intended audience or produces repeated expectation mismatch. Repeated onboarding hesitation changes the product/try path first. A verified, accessible player community would justify comparing that alternative, but no platform permission is inferred now. The concrete next action is to prepare the three-session observation sheet and owner scheduling plan.
