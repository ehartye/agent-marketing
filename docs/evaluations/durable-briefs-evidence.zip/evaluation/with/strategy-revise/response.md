# Final user response

Revised the strategy to **pause increasing reach and prioritize three first sessions**. I retained the relaxing-game audience, five-minute promise, payoff hypothesis, YouTube history, conditional Reddit alternative and separate return-cohort requirement.

The plan fits **180 minutes and USD 0** for 9–15 October. On **15 October**, repeated hesitation in two sessions means change one first-use element and retest; three unaided completions permits considering a bounded YouTube follow-up. Revisit the channel if a clear opening still brings unsuitable players or mismatched expectations through a later tagged test. These are decision rules, not results from the synthetic data.

Saved and verified project **orbit**; orbit-video is paused and orbit-playtest remains planned. Reopen **Decide & plan → Project strategy**. Workspace: .agent-marketing/brief-eval/with/strategy-revise/workspace.json. Next: prepare the session sheet and owner scheduling plan.

Full saved deliverable: [strategy.md](strategy.md).

# Execution notes

Existing saved documents were read before revision. All writes, readbacks and final validations succeeded. No global runtime installation, external posting, spending, outreach or wiki/product-file edits were performed. Development CLI invocation was explicitly authorized.


Sources checked with web tool on 2026-10-08: https://support.google.com/youtube/answer/2801973?hl=en (spam/deceptive promotion); https://support.google.com/youtube/answer/13748639?hl=en (clickable link surfaces); https://support.google.com/analytics/answer/10917952?hl=en (UTM campaign/content parameters). Published rules constrain execution; channel choice and numeric review criteria are planning inferences.

# Full saved deliverable

# Orbit Garden strategy — revised 8 October 2026

Retain the existing audience and promise: relaxing-game fans seeking a five-minute break, growing a little world in one short round. Retain the visible-payoff hypothesis, the existing YouTube discovery test as historical context, and the requirement for a defined return cohort. The change is operational: pause increasing reach, including orbit-video, and make three direct first sessions the only active planned work for 9–15 October. Owner: Family studio; three maker-hours and USD 0 this week.

## Reasoning preserved and limits

The saved strategy's 90 visitors and eight starts are synthetic illustrations of a first-use question, not market demand. The workspace also includes a reviewed seed-choice hesitation and an unreviewed mobile-control complaint. Review the latter as a lead, not a verified diagnosis. The example source https://example.com/demo-evidence is not live proof. Do not calculate retention from the one return without verified identities/window. Do not add overlapping daily and weekly view rows. The existing randomized hint test remains under its own target; these qualitative sessions do not replace its stopping rule.

Assume neither three available participants nor a working try URL: check both before execution. Direct means owner-arranged in-person observation; no social platform, community permission or email list is assumed. The planning record authorizes no contact. Reddit remains the prior strategy's conditional alternative, outside the initiatives ledger until a specific community, its audience, platform rules and local posting permission have been verified.

## Choices and tradeoffs

| Choice | Time/lag | Spending/risk | Complexity/best practice | Maintainability |
|---|---|---|---|---|
| Direct three-session test now | 180 minutes total; same-session feedback, scheduling may slip | USD 0; three people are a convenience sample, coaching can bias behavior | Low setup; test an unchanged build and record behavior before prompting | Short notes and a bounded review; no standing moderation work |
| Continue increasing YouTube reach now | At least an hour of production plus response/review; plays may take days | USD 0 organic but risks spending scarce time on traffic before first use works | Existing channel is convenient; truthful gameplay and attribution still needed | Ongoing comments/support compete with observation time; paused |
| YouTube as sustainable follow-up | Reuse one gameplay capture in a later week, no cadence promise | USD 0; selection and attribution uncertainty persist | Already represented in ledger; show action then payoff and one try CTA | Maintain link and answer questions within the next week's cap |

CLI channel ranking is a planning heuristic only. [Current YouTube rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive metadata and spam; [link guidance](https://support.google.com/youtube/answer/13748639?hl=en) distinguishes non-clickable Shorts URLs from long-form links requiring advanced features. Checked 8 October 2026. These support a possible later execution format, not a claim that YouTube will perform best. Direct in-person observation does not require a community posting route.

## Audience → message → asset → CTA → measurement

Audience: three first-time players who enjoy relaxing games. Draft message: “We're checking whether Orbit Garden's opening is clear. Try a short round and describe where you hesitate.” Asset: unchanged current build and a blank session sheet. CTA: “Try a round and describe where you hesitate.” Do not prime them with an instructional clip. Record build/device, first visible action and time, exact hesitation, assistance, first-round completion, and voluntary interest in another session. A request to save is not an implemented save feature.

Time: 25 minutes build/device checks, 20 scheduling/consent, three 20-minute sessions, 35 synthesis, 20 drafting a single clarification proposal, 20 buffer = 180. No extra clip production this week. If availability fails, spend no more than the scheduling allocation and flag insufficient evidence. Keep orbit-playtest planned, direct, 9–15 October, budget 0; retain the paused video and all historical data. Product changes wait for observed evidence and separate implementation work.

## Review: 15 October 2026

Count unaided first actions and completed rounds separately out of three. All three completing without help permits considering a bounded YouTube follow-up; it does not demonstrate conversion or retention. A shared hesitation in at least two means change one first-use element and retest before increasing reach. One isolated issue gets a targeted follow-up; fewer than three sessions is insufficient evidence. Stop on a broken build or the three-hour cap.

Revisit the channel choice if the opening is clear but a subsequent tagged YouTube test attracts players outside the intended audience or produces repeated expectation mismatch. Repeated onboarding hesitation changes the product/try path first. A verified, accessible player community would justify comparing that alternative, but no platform permission is inferred now. The concrete next action is to prepare the three-session observation sheet and owner scheduling plan.


# Actual commands and results

Development invocation was explicitly permitted; no managed runtime installation was run. Node v24.18.0. Read local named SKILL.md, craft references, docs/CLI.md, setup and (for campaigns) collateral instructions.

```text
node scripts/marketing.mjs help --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "name": "marketing",
  "version": "0.1.0",
  "workspace": "--workspace <file> (default .agent-marketing/workspace.json)",
  "commands": [
    "init",
    "demo",
    "validate",
    "import <json-or-csv>",
    "put <collection> <record.json>",
    "document save <strategy|campaign> <record-id> <brief.md> --revision n",
    "document show <strategy|campaign> <record-id>",
    "document export <strategy|campaign> <record-id> [--out brief.md]",
    "report [--project id --initiative id --from date --to date]",
    "advise <project-id>",
    "channels [project-id]",
    "experiment <experiment-id>",
    "utm <url> --source x --medium y --campaign z [--content c]",
    "monitor [--source id]",
    "serve [--port 4318]",
    "export [--format json|csv] [--out file]",
    "rules [topic]",
    "help"
  ]
}
```

```text
node scripts/marketing.mjs rules measurement --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
[
  {
    "id": "attribution-not-causality",
    "topic": "measurement",
    "kind": "external",
    "rule": "Tagged visits and attributed conversions do not prove incremental causal effects.",
    "referenceIds": [
      "measurement",
      "causality"
    ]
  },
  {
    "id": "reach-is-not-people",
    "topic": "measurement",
    "kind": "derived",
    "rule": "Do not sum platform reach into unique people without deduplicated identities and permission to use them.",
    "referenceIds": [
      "ga4-schema",
      "github-traffic"
    ],
    "reason": "Repeated visitors and overlapping platform audiences violate distinct-person addition."
  },
  {
    "id": "definitions-and-windows",
    "topic": "measurement",
    "kind": "external",
    "rule": "Preserve raw metric definition, period, source and collection time; compare only compatible reporting scopes.",
    "referenceIds": [
      "youtube",
      "ga4-schema",
      "github-traffic"
    ]
  }
]
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 0,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\strategy-revise\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 0,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
    "updatedAt": "2026-10-08T12:00:00.000Z"
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit"
  },
  "uniqueReach": null,
  "totals": [
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "views",
      "value": 2400,
      "evidence": [
        "orbit-views"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "definition": "visitors",
      "value": 90,
      "evidence": [
        "orbit-visitors"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "definition": "starts",
      "value": 8,
      "evidence": [
        "orbit-starts"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "definition": "returns",
      "value": 1,
      "evidence": [
        "orbit-returns"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "definition": "cost",
      "currency": "USD",
      "value": 0,
      "evidence": [
        "orbit-cost"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "YouTube playback starts (daily demo)",
      "value": 2400,
      "evidence": [
        "orbit-daily-2026-10-01",
        "orbit-daily-2026-10-02",
        "orbit-daily-2026-10-03",
        "orbit-daily-2026-10-04",
        "orbit-daily-2026-10-05",
        "orbit-daily-2026-10-06",
        "orbit-daily-2026-10-07"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-01",
          "kind": "period"
        },
        {
          "start": "2026-10-02",
          "end": "2026-10-02",
          "kind": "period"
        },
        {
          "start": "2026-10-03",
          "end": "2026-10-03",
          "kind": "period"
        },
        {
          "start": "2026-10-04",
          "end": "2026-10-04",
          "kind": "period"
        },
        {
          "start": "2026-10-05",
          "end": "2026-10-05",
          "kind": "period"
        },
        {
          "start": "2026-10-06",
          "end": "2026-10-06",
          "kind": "period"
        },
        {
          "start": "2026-10-07",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    }
  ],
  "sentiment": {
    "positive": 2,
    "negative": 0,
    "neutral": 0,
    "mixed": 1,
    "unknown": 0,
    "unreviewed": 2
  },
  "funnels": [
    {
      "channel": "youtube",
      "initiativeId": "orbit-video",
      "visitors": 90,
      "starts": 8,
      "rate": 0.08888888888888889,
      "evidence": [
        "orbit-visitors",
        "orbit-starts"
      ],
      "interpretation": "Observed ratio; counts may represent different people"
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "name": "First action: label versus animated hint",
      "arms": [
        {
          "name": "A · text label",
          "interval": {
            "rate": 0.16666666666666666,
            "low": 0.05836576805861446,
            "high": 0.39222038103915724,
            "trials": 18,
            "successes": 3
          }
        },
        {
          "name": "B · animated hint",
          "interval": {
            "rate": 0.23809523809523808,
            "low": 0.10628013022636468,
            "high": 0.4509117368295075,
            "trials": 21,
            "successes": 5
          }
        }
      ],
      "difference": {
        "low": -0.28594025081279256,
        "high": 0.3925459687708931,
        "estimate": 0.07142857142857142
      },
      "decision": "collect",
      "ready": false,
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "caveat": "Conservative interval from separate Wilson bounds, not a calibrated hypothesis test. Prespecify duration, allocation and stopping; no causal winner from nonrandom groups or repeated peeking."
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": [],
  "warnings": [
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

```text
node scripts/marketing.mjs channels orbit --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
[
  {
    "id": "youtube",
    "name": "YouTube",
    "categories": [
      "game",
      "creative",
      "education"
    ],
    "audiences": [
      "player",
      "artist",
      "learner",
      "parent"
    ],
    "hours": 3,
    "cost": "0 plus production effort",
    "approach": "Show the payoff or a useful tutorial with a directly tryable next step",
    "measure": "Engaged viewing, tagged visits, successful first use and return",
    "risk": "Public playback starts can look impressive without product interest",
    "complexity": "Moderate production; definitions and reporting delay matter",
    "maintainability": "Batch footage; keep one reusable demonstration format",
    "referenceIds": [
      "youtube",
      "measurement"
    ],
    "planningScore": 6,
    "rationale": [
      "Format suits the project category",
      "Audience description matches a channel cue",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "itch",
    "name": "itch.io and game communities",
    "categories": [
      "game"
    ],
    "audiences": [
      "player",
      "indie"
    ],
    "hours": 2,
    "cost": "0 to start; verify current terms",
    "approach": "Playable demo, genre-readable screenshots and a brief development log",
    "measure": "Qualified plays, completion and returning players",
    "risk": "Audience and device fit may differ from your intended players",
    "complexity": "Moderate asset preparation and distribution setup",
    "maintainability": "Maintain the playable build and respond to bug reports",
    "referenceIds": [
      "player-discovery",
      "campaign"
    ],
    "planningScore": 6,
    "rationale": [
      "Format suits the project category",
      "Audience description matches a channel cue",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "reddit",
    "name": "Relevant Reddit communities",
    "categories": [
      "tool",
      "app",
      "game",
      "education",
      "creative"
    ],
    "audiences": [
      "community"
    ],
    "hours": 2,
    "cost": "0",
    "approach": "Inspect community rules; contribute a useful native explanation where promotion is welcome",
    "measure": "Objections, tagged use and return from the specific community",
    "risk": "Repetitive promotion can be spam; no blanket posting allowance",
    "complexity": "Community-by-community judgment and participation",
    "maintainability": "Build relationships; do not run a promotional bot",
    "referenceIds": [
      "reddit"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "email",
    "name": "Opt-in email",
    "categories": [
      "tool",
      "app",
      "game",
      "education",
      "creative"
    ],
    "audiences": [
      "existing"
    ],
    "hours": 1,
    "cost": "Provider costs vary",
    "approach": "Useful update to people who opted in; one clear next action",
    "measure": "Tagged successful use and unsubscribes; treat opens cautiously",
    "risk": "A small list limits discovery; unwanted mail harms trust",
    "complexity": "Consent, list care and deliverability",
    "maintainability": "Keep the cadence sustainable and honor unsubscribes",
    "referenceIds": [
      "measurement"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "discord",
    "name": "Existing Discord community",
    "categories": [
      "game",
      "tool",
      "creative"
    ],
    "audiences": [
      "existing",
      "community"
    ],
    "hours": 2,
    "cost": "0 plus ongoing care",
    "approach": "Share useful progress and invite focused feedback in a relevant existing community",
    "measure": "Playtest participation, recurring use and qualitative themes",
    "risk": "Starting a new empty server creates moderation work before demand",
    "complexity": "Moderation and community rules",
    "maintainability": "Only open your own community when you can sustain it",
    "referenceIds": [
      "player-discovery"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "github",
    "name": "GitHub",
    "categories": [
      "tool"
    ],
    "audiences": [
      "developer",
      "coder",
      "engineer"
    ],
    "hours": 1,
    "cost": "0",
    "approach": "Useful README, working quickstart, example project and release notes",
    "measure": "Repository traffic plus downstream successful installs/use",
    "risk": "Stars can come from curiosity; rolling traffic history is short",
    "complexity": "Low; public metrics or repository-scoped read token",
    "maintainability": "Keep examples tested and collect traffic weekly",
    "referenceIds": [
      "github-traffic"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "hacker-news",
    "name": "Show HN",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "developer",
      "maker",
      "engineer"
    ],
    "hours": 2,
    "cost": "0",
    "approach": "Tryable substantive project, maker explanation and thoughtful replies",
    "measure": "Thread feedback and tagged product activation",
    "risk": "One-off generated projects and signup-only pages may be ineligible",
    "complexity": "Low setup; launch timing and discussion are unpredictable",
    "maintainability": "Be available for support; no repeated routine version posts",
    "referenceIds": [
      "channels",
      "hn-api"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "search",
    "name": "Search and useful documentation",
    "categories": [
      "tool",
      "app",
      "education"
    ],
    "audiences": [
      "learner",
      "developer",
      "user"
    ],
    "hours": 3,
    "cost": "0 plus sustained writing",
    "approach": "Answer a real recurring question with a useful page and a working example",
    "measure": "Qualified search visits and successful use",
    "risk": "Slow feedback; ranking is not guaranteed",
    "complexity": "Instrumentation, indexable pages and topic judgment",
    "maintainability": "Update examples and monitor query intent",
    "referenceIds": [
      "discovery",
      "measurement"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "linkedin",
    "name": "LinkedIn",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "professional",
      "business"
    ],
    "hours": 2,
    "cost": "0 for organic participation",
    "approach": "Concrete before/after workflow for the professional audience",
    "measure": "Qualified conversations and product use",
    "risk": "Impressions and generic praise can be weak demand signals",
    "complexity": "Requires clear professional relevance and a credible demo",
    "maintainability": "Reuse actual user stories with permission",
    "referenceIds": [
      "positioning",
      "measurement"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "product-hunt",
    "name": "Product Hunt",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "maker",
      "early adopter"
    ],
    "hours": 3,
    "cost": "0 for a basic launch; verify current terms",
    "approach": "Prepared maker launch with concise gallery, demo and available support",
    "measure": "Tagged activation and thoughtful feedback",
    "risk": "Launch-day rank is not durable demand; do not solicit upvotes",
    "complexity": "Moderate preparation, fast discussion response",
    "maintainability": "Plan support and a follow-up beyond launch day",
    "referenceIds": [
      "product-hunt"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  }
]
```

```text
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/strategy-revise/initiative-patch.json --revision 0 --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "schema": "marketing/workspace@1",
  "revision": 1,
  "projects": [
    {
      "id": "orbit",
      "name": "Orbit Garden · demo",
      "audience": [
        "indie players",
        "relaxing-game fans"
      ],
      "category": "game",
      "problem": "A relaxing five-minute break",
      "promise": "Grow a little world in five minutes",
      "stage": "beta",
      "objective": "Learn whether 20 new players return for a second session",
      "weeklyHours": 3,
      "budget": 300,
      "currency": "USD",
      "strategy": {
        "markdown": "# Orbit Garden strategy — synthetic demo\n\n## Audience and promise\nRelaxing-game fans who want a five-minute break. Grow a little world in one short round.\n\n## Channel choice and rationale\nUse the existing YouTube clip as one bounded discovery test. The demo ledger has 90 attributed visitors and 8 starts; those synthetic counts illustrate an activation question, not market demand. Prioritize a direct first-round playtest before increasing reach. Reddit remains a conditional alternative pending community fit and posting permission.\n\n## Assumptions and evidence\nAll counts and claims in this workspace are examples, not observed commercial evidence. Source placeholder: https://example.com/demo-evidence. The hypothesis that a visible payoff brings qualified players remains untested. Returning players require a defined follow-up cohort.\n\n## Effort and next decision\nOwner: Family studio. Limit the next test to three maker-hours and no ad spend. Inspect three intended-player sessions; change one repeated point of confusion, then measure starts and return use with consistent definitions. Review on 2026-10-15. Do not increase distribution until the first-use problem is understood.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "sketch",
      "name": "Sketch Relay · demo",
      "audience": [
        "developers",
        "creative makers"
      ],
      "category": "tool",
      "problem": "Sharing a quick UI idea takes too long",
      "promise": "Turn a rough sketch into a runnable interaction",
      "stage": "prototype",
      "objective": "Observe five successful first-use sessions",
      "weeklyHours": 2,
      "budget": 50,
      "currency": "USD"
    }
  ],
  "initiatives": [
    {
      "id": "orbit-video",
      "projectId": "orbit",
      "name": "A planet in one coffee break",
      "channel": "youtube",
      "hypothesis": "A clip of the payoff brings players who try a full round",
      "cta": "Play a five-minute round",
      "status": "paused",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio",
      "brief": {
        "markdown": "# A planet in one coffee break — synthetic campaign brief\n\n## Audience and hypothesis\nFor relaxing-game fans: a short clip of growing a tiny planet will bring players who complete a first round. This is a demonstration hypothesis, not a validated result.\n\n## Message, asset and CTA\nDraft caption: Grow a little world in five minutes. Show the first action and its visible payoff in a short gameplay capture. Asset: capture still to be produced. CTA: Play a five-minute round. No publication is authorized by this sample.\n\n## Measurement\nUse an initiative-tagged try link. Record attributed visitors and starts over the same period, plus a separately defined return cohort. Reach alone is not success. Inspect with: marketing report --project orbit --initiative orbit-video --workspace <ledger>.\n\n## Constraints and review\nOwner: Family studio. Dates: 2026-10-01 through 2026-10-14. Budget: 0 USD; cap clip preparation at one hour. Review on 2026-10-14. Continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause the clip if support or preparation exceeds the cap.\n\n## Evidence and limits\nRead the saved Orbit Garden strategy for the shared rationale. Demo source: https://example.com/demo-evidence. Synthetic counts do not establish channel effectiveness, payment intent or a causal effect.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "orbit-playtest",
      "projectId": "orbit",
      "name": "First round playtest",
      "channel": "direct",
      "hypothesis": "Observing three unchanged first sessions reveals repeated first-action hesitation before increasing reach",
      "cta": "Try a round and describe where you hesitate",
      "status": "planned",
      "start": "2026-10-09",
      "end": "2026-10-15",
      "budget": 0,
      "owner": "Family studio"
    },
    {
      "id": "sketch-github",
      "projectId": "sketch",
      "name": "A working example worth cloning",
      "channel": "github",
      "hypothesis": "A short runnable example activates developers better than feature lists",
      "cta": "Run the starter example",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio"
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-visitors",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "visitors",
      "value": 62,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-starts",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "starts",
      "value": 18,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-stars",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "stars",
      "value": 41,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "snapshot",
      "definition": "stars",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "series": "sketch-stars"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r6",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "text": "Useful example. I needed clearer setup instructions.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "installation"
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    },
    {
      "id": "sketch-substitute",
      "projectId": "sketch",
      "name": "Screenshot plus chat message",
      "kind": "substitute",
      "positioning": "Already available and easy to share, but cannot demonstrate interaction",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "projectId": "orbit",
      "name": "First action: label versus animated hint",
      "hypothesis": "A visible hint improves first-round starts",
      "primaryMetric": "Unique assigned visitors completing a first round within one session",
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · text label",
          "trials": 18,
          "successes": 3
        },
        {
          "name": "B · animated hint",
          "trials": 21,
          "successes": 5
        }
      ]
    },
    {
      "id": "sketch-install",
      "projectId": "sketch",
      "name": "Runnable README example versus feature list",
      "hypothesis": "A runnable example improves first successful setup",
      "primaryMetric": "Assigned developers successfully running the example",
      "stoppingRule": "Compare after 100 unique assigned visitors per arm over a full two-week window; report failures separately",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · feature list",
          "trials": 100,
          "successes": 11
        },
        {
          "name": "B · example",
          "trials": 100,
          "successes": 39
        }
      ]
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "sketch-problem",
      "projectId": "sketch",
      "dimension": "problem",
      "claim": "Three synthetic maker interviews describe a recent need for a runnable sketch",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": []
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 1,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document save strategy orbit .agent-marketing/brief-eval/with/strategy-revise/strategy.md --revision 1 --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\strategy-revise\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 2,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden strategy — revised 8 October 2026\n\nRetain the existing audience and promise: relaxing-game fans seeking a five-minute break, growing a little world in one short round. Retain the visible-payoff hypothesis, the existing YouTube discovery test as historical context, and the requirement for a defined return cohort. The change is operational: pause increasing reach, including orbit-video, and make three direct first sessions the only active planned work for 9–15 October. Owner: Family studio; three maker-hours and USD 0 this week.\n\n## Reasoning preserved and limits\n\nThe saved strategy's 90 visitors and eight starts are synthetic illustrations of a first-use question, not market demand. The workspace also includes a reviewed seed-choice hesitation and an unreviewed mobile-control complaint. Review the latter as a lead, not a verified diagnosis. The example source https://example.com/demo-evidence is not live proof. Do not calculate retention from the one return without verified identities/window. Do not add overlapping daily and weekly view rows. The existing randomized hint test remains under its own target; these qualitative sessions do not replace its stopping rule.\n\nAssume neither three available participants nor a working try URL: check both before execution. Direct means owner-arranged in-person observation; no social platform, community permission or email list is assumed. The planning record authorizes no contact. Reddit remains the prior strategy's conditional alternative, outside the initiatives ledger until a specific community, its audience, platform rules and local posting permission have been verified.\n\n## Choices and tradeoffs\n\n| Choice | Time/lag | Spending/risk | Complexity/best practice | Maintainability |\n|---|---|---|---|---|\n| Direct three-session test now | 180 minutes total; same-session feedback, scheduling may slip | USD 0; three people are a convenience sample, coaching can bias behavior | Low setup; test an unchanged build and record behavior before prompting | Short notes and a bounded review; no standing moderation work |\n| Continue increasing YouTube reach now | At least an hour of production plus response/review; plays may take days | USD 0 organic but risks spending scarce time on traffic before first use works | Existing channel is convenient; truthful gameplay and attribution still needed | Ongoing comments/support compete with observation time; paused |\n| YouTube as sustainable follow-up | Reuse one gameplay capture in a later week, no cadence promise | USD 0; selection and attribution uncertainty persist | Already represented in ledger; show action then payoff and one try CTA | Maintain link and answer questions within the next week's cap |\n\nCLI channel ranking is a planning heuristic only. [Current YouTube rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive metadata and spam; [link guidance](https://support.google.com/youtube/answer/13748639?hl=en) distinguishes non-clickable Shorts URLs from long-form links requiring advanced features. Checked 8 October 2026. These support a possible later execution format, not a claim that YouTube will perform best. Direct in-person observation does not require a community posting route.\n\n## Audience → message → asset → CTA → measurement\n\nAudience: three first-time players who enjoy relaxing games. Draft message: “We're checking whether Orbit Garden's opening is clear. Try a short round and describe where you hesitate.” Asset: unchanged current build and a blank session sheet. CTA: “Try a round and describe where you hesitate.” Do not prime them with an instructional clip. Record build/device, first visible action and time, exact hesitation, assistance, first-round completion, and voluntary interest in another session. A request to save is not an implemented save feature.\n\nTime: 25 minutes build/device checks, 20 scheduling/consent, three 20-minute sessions, 35 synthesis, 20 drafting a single clarification proposal, 20 buffer = 180. No extra clip production this week. If availability fails, spend no more than the scheduling allocation and flag insufficient evidence. Keep orbit-playtest planned, direct, 9–15 October, budget 0; retain the paused video and all historical data. Product changes wait for observed evidence and separate implementation work.\n\n## Review: 15 October 2026\n\nCount unaided first actions and completed rounds separately out of three. All three completing without help permits considering a bounded YouTube follow-up; it does not demonstrate conversion or retention. A shared hesitation in at least two means change one first-use element and retest before increasing reach. One isolated issue gets a targeted follow-up; fewer than three sessions is insufficient evidence. Stop on a broken build or the three-hour cap.\n\nRevisit the channel choice if the opening is clear but a subsequent tagged YouTube test attracts players outside the intended audience or produces repeated expectation mismatch. Repeated onboarding hesitation changes the product/try path first. A verified, accessible player community would justify comparing that alternative, but no platform permission is inferred now. The concrete next action is to prepare the three-session observation sheet and owner scheduling plan.\n",
    "updatedAt": "2026-10-08T19:09:40.802Z"
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\strategy-revise\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 2,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden strategy — revised 8 October 2026\n\nRetain the existing audience and promise: relaxing-game fans seeking a five-minute break, growing a little world in one short round. Retain the visible-payoff hypothesis, the existing YouTube discovery test as historical context, and the requirement for a defined return cohort. The change is operational: pause increasing reach, including orbit-video, and make three direct first sessions the only active planned work for 9–15 October. Owner: Family studio; three maker-hours and USD 0 this week.\n\n## Reasoning preserved and limits\n\nThe saved strategy's 90 visitors and eight starts are synthetic illustrations of a first-use question, not market demand. The workspace also includes a reviewed seed-choice hesitation and an unreviewed mobile-control complaint. Review the latter as a lead, not a verified diagnosis. The example source https://example.com/demo-evidence is not live proof. Do not calculate retention from the one return without verified identities/window. Do not add overlapping daily and weekly view rows. The existing randomized hint test remains under its own target; these qualitative sessions do not replace its stopping rule.\n\nAssume neither three available participants nor a working try URL: check both before execution. Direct means owner-arranged in-person observation; no social platform, community permission or email list is assumed. The planning record authorizes no contact. Reddit remains the prior strategy's conditional alternative, outside the initiatives ledger until a specific community, its audience, platform rules and local posting permission have been verified.\n\n## Choices and tradeoffs\n\n| Choice | Time/lag | Spending/risk | Complexity/best practice | Maintainability |\n|---|---|---|---|---|\n| Direct three-session test now | 180 minutes total; same-session feedback, scheduling may slip | USD 0; three people are a convenience sample, coaching can bias behavior | Low setup; test an unchanged build and record behavior before prompting | Short notes and a bounded review; no standing moderation work |\n| Continue increasing YouTube reach now | At least an hour of production plus response/review; plays may take days | USD 0 organic but risks spending scarce time on traffic before first use works | Existing channel is convenient; truthful gameplay and attribution still needed | Ongoing comments/support compete with observation time; paused |\n| YouTube as sustainable follow-up | Reuse one gameplay capture in a later week, no cadence promise | USD 0; selection and attribution uncertainty persist | Already represented in ledger; show action then payoff and one try CTA | Maintain link and answer questions within the next week's cap |\n\nCLI channel ranking is a planning heuristic only. [Current YouTube rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive metadata and spam; [link guidance](https://support.google.com/youtube/answer/13748639?hl=en) distinguishes non-clickable Shorts URLs from long-form links requiring advanced features. Checked 8 October 2026. These support a possible later execution format, not a claim that YouTube will perform best. Direct in-person observation does not require a community posting route.\n\n## Audience → message → asset → CTA → measurement\n\nAudience: three first-time players who enjoy relaxing games. Draft message: “We're checking whether Orbit Garden's opening is clear. Try a short round and describe where you hesitate.” Asset: unchanged current build and a blank session sheet. CTA: “Try a round and describe where you hesitate.” Do not prime them with an instructional clip. Record build/device, first visible action and time, exact hesitation, assistance, first-round completion, and voluntary interest in another session. A request to save is not an implemented save feature.\n\nTime: 25 minutes build/device checks, 20 scheduling/consent, three 20-minute sessions, 35 synthesis, 20 drafting a single clarification proposal, 20 buffer = 180. No extra clip production this week. If availability fails, spend no more than the scheduling allocation and flag insufficient evidence. Keep orbit-playtest planned, direct, 9–15 October, budget 0; retain the paused video and all historical data. Product changes wait for observed evidence and separate implementation work.\n\n## Review: 15 October 2026\n\nCount unaided first actions and completed rounds separately out of three. All three completing without help permits considering a bounded YouTube follow-up; it does not demonstrate conversion or retention. A shared hesitation in at least two means change one first-use element and retest before increasing reach. One isolated issue gets a targeted follow-up; fewer than three sessions is insufficient evidence. Stop on a broken build or the three-hour cap.\n\nRevisit the channel choice if the opening is clear but a subsequent tagged YouTube test attracts players outside the intended audience or produces repeated expectation mismatch. Repeated onboarding hesitation changes the product/try path first. A verified, accessible player community would justify comparing that alternative, but no platform permission is inferred now. The concrete next action is to prepare the three-session observation sheet and owner scheduling plan.\n",
    "updatedAt": "2026-10-08T19:09:40.802Z"
  }
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "ok": true,
  "revision": 2,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/strategy-revise/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit",
    "initiativeId": "orbit-playtest",
    "from": "2026-10-09",
    "to": "2026-10-15"
  },
  "uniqueReach": null,
  "totals": [],
  "observations": [],
  "reactions": [],
  "sentiment": {
    "positive": 0,
    "negative": 0,
    "neutral": 0,
    "mixed": 0,
    "unknown": 0,
    "unreviewed": 0
  },
  "funnels": [],
  "experiments": [],
  "competitors": [],
  "evidence": [],
  "sources": [],
  "warnings": [
    "Only observations fully contained in the date filter are included; period totals cannot be prorated.",
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

Readback equality: PASS. All prior record IDs retained; observations, reactions, competitors, experiments, evidence and sources byte-equivalent as parsed values. Final revision 2. No execution outcomes inserted.
