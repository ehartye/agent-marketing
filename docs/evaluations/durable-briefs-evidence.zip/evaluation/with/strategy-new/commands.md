# Actual commands and results

Development invocation was explicitly permitted; no managed runtime installation was run. Node v24.18.0. Read local named SKILL.md, craft references, docs/CLI.md, setup and (for campaigns) collateral instructions.

```text
node scripts/marketing.mjs help --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "name": "marketing",
  "version": "0.1.0",
  "workspace": "--workspace <file> (default .agent-marketing/workspace.json)",
  "commands": [
    "init",
    "demo",
    "validate",
    "import <json-or-csv>",
    "put <collection> <record.json>",
    "document save <strategy|campaign> <record-id> <brief.md> --revision n",
    "document show <strategy|campaign> <record-id>",
    "document export <strategy|campaign> <record-id> [--out brief.md]",
    "report [--project id --initiative id --from date --to date]",
    "advise <project-id>",
    "channels [project-id]",
    "experiment <experiment-id>",
    "utm <url> --source x --medium y --campaign z [--content c]",
    "monitor [--source id]",
    "serve [--port 4318]",
    "export [--format json|csv] [--out file]",
    "rules [topic]",
    "help"
  ]
}
```

```text
node scripts/marketing.mjs rules measurement --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
[
  {
    "id": "attribution-not-causality",
    "topic": "measurement",
    "kind": "external",
    "rule": "Tagged visits and attributed conversions do not prove incremental causal effects.",
    "referenceIds": [
      "measurement",
      "causality"
    ]
  },
  {
    "id": "reach-is-not-people",
    "topic": "measurement",
    "kind": "derived",
    "rule": "Do not sum platform reach into unique people without deduplicated identities and permission to use them.",
    "referenceIds": [
      "ga4-schema",
      "github-traffic"
    ],
    "reason": "Repeated visitors and overlapping platform audiences violate distinct-person addition."
  },
  {
    "id": "definitions-and-windows",
    "topic": "measurement",
    "kind": "external",
    "rule": "Preserve raw metric definition, period, source and collection time; compare only compatible reporting scopes.",
    "referenceIds": [
      "youtube",
      "ga4-schema",
      "github-traffic"
    ]
  }
]
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 0,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 2
{"error":{"code":"E_COMMAND","message":"No strategy document saved for orbit"}}
```

```text
node scripts/marketing.mjs report --project orbit --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit"
  },
  "uniqueReach": null,
  "totals": [
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "views",
      "value": 2400,
      "evidence": [
        "orbit-views"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "definition": "visitors",
      "value": 90,
      "evidence": [
        "orbit-visitors"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "definition": "starts",
      "value": 8,
      "evidence": [
        "orbit-starts"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "definition": "returns",
      "value": 1,
      "evidence": [
        "orbit-returns"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "definition": "cost",
      "currency": "USD",
      "value": 0,
      "evidence": [
        "orbit-cost"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    },
    {
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "definition": "YouTube playback starts (daily demo)",
      "value": 2400,
      "evidence": [
        "orbit-daily-2026-10-01",
        "orbit-daily-2026-10-02",
        "orbit-daily-2026-10-03",
        "orbit-daily-2026-10-04",
        "orbit-daily-2026-10-05",
        "orbit-daily-2026-10-06",
        "orbit-daily-2026-10-07"
      ],
      "periods": [
        {
          "start": "2026-10-01",
          "end": "2026-10-01",
          "kind": "period"
        },
        {
          "start": "2026-10-02",
          "end": "2026-10-02",
          "kind": "period"
        },
        {
          "start": "2026-10-03",
          "end": "2026-10-03",
          "kind": "period"
        },
        {
          "start": "2026-10-04",
          "end": "2026-10-04",
          "kind": "period"
        },
        {
          "start": "2026-10-05",
          "end": "2026-10-05",
          "kind": "period"
        },
        {
          "start": "2026-10-06",
          "end": "2026-10-06",
          "kind": "period"
        },
        {
          "start": "2026-10-07",
          "end": "2026-10-07",
          "kind": "period"
        }
      ],
      "ambiguous": false
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    }
  ],
  "sentiment": {
    "positive": 2,
    "negative": 0,
    "neutral": 0,
    "mixed": 1,
    "unknown": 0,
    "unreviewed": 2
  },
  "funnels": [
    {
      "channel": "youtube",
      "initiativeId": "orbit-video",
      "visitors": 90,
      "starts": 8,
      "rate": 0.08888888888888889,
      "evidence": [
        "orbit-visitors",
        "orbit-starts"
      ],
      "interpretation": "Observed ratio; counts may represent different people"
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "name": "First action: label versus animated hint",
      "arms": [
        {
          "name": "A · text label",
          "interval": {
            "rate": 0.16666666666666666,
            "low": 0.05836576805861446,
            "high": 0.39222038103915724,
            "trials": 18,
            "successes": 3
          }
        },
        {
          "name": "B · animated hint",
          "interval": {
            "rate": 0.23809523809523808,
            "low": 0.10628013022636468,
            "high": 0.4509117368295075,
            "trials": 21,
            "successes": 5
          }
        }
      ],
      "difference": {
        "low": -0.28594025081279256,
        "high": 0.3925459687708931,
        "estimate": 0.07142857142857142
      },
      "decision": "collect",
      "ready": false,
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "caveat": "Conservative interval from separate Wilson bounds, not a calibrated hypothesis test. Prespecify duration, allocation and stopping; no causal winner from nonrandom groups or repeated peeking."
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": [],
  "warnings": [
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

```text
node scripts/marketing.mjs channels orbit --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
[
  {
    "id": "youtube",
    "name": "YouTube",
    "categories": [
      "game",
      "creative",
      "education"
    ],
    "audiences": [
      "player",
      "artist",
      "learner",
      "parent"
    ],
    "hours": 3,
    "cost": "0 plus production effort",
    "approach": "Show the payoff or a useful tutorial with a directly tryable next step",
    "measure": "Engaged viewing, tagged visits, successful first use and return",
    "risk": "Public playback starts can look impressive without product interest",
    "complexity": "Moderate production; definitions and reporting delay matter",
    "maintainability": "Batch footage; keep one reusable demonstration format",
    "referenceIds": [
      "youtube",
      "measurement"
    ],
    "planningScore": 6,
    "rationale": [
      "Format suits the project category",
      "Audience description matches a channel cue",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "itch",
    "name": "itch.io and game communities",
    "categories": [
      "game"
    ],
    "audiences": [
      "player",
      "indie"
    ],
    "hours": 2,
    "cost": "0 to start; verify current terms",
    "approach": "Playable demo, genre-readable screenshots and a brief development log",
    "measure": "Qualified plays, completion and returning players",
    "risk": "Audience and device fit may differ from your intended players",
    "complexity": "Moderate asset preparation and distribution setup",
    "maintainability": "Maintain the playable build and respond to bug reports",
    "referenceIds": [
      "player-discovery",
      "campaign"
    ],
    "planningScore": 6,
    "rationale": [
      "Format suits the project category",
      "Audience description matches a channel cue",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "reddit",
    "name": "Relevant Reddit communities",
    "categories": [
      "tool",
      "app",
      "game",
      "education",
      "creative"
    ],
    "audiences": [
      "community"
    ],
    "hours": 2,
    "cost": "0",
    "approach": "Inspect community rules; contribute a useful native explanation where promotion is welcome",
    "measure": "Objections, tagged use and return from the specific community",
    "risk": "Repetitive promotion can be spam; no blanket posting allowance",
    "complexity": "Community-by-community judgment and participation",
    "maintainability": "Build relationships; do not run a promotional bot",
    "referenceIds": [
      "reddit"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "email",
    "name": "Opt-in email",
    "categories": [
      "tool",
      "app",
      "game",
      "education",
      "creative"
    ],
    "audiences": [
      "existing"
    ],
    "hours": 1,
    "cost": "Provider costs vary",
    "approach": "Useful update to people who opted in; one clear next action",
    "measure": "Tagged successful use and unsubscribes; treat opens cautiously",
    "risk": "A small list limits discovery; unwanted mail harms trust",
    "complexity": "Consent, list care and deliverability",
    "maintainability": "Keep the cadence sustainable and honor unsubscribes",
    "referenceIds": [
      "measurement"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "discord",
    "name": "Existing Discord community",
    "categories": [
      "game",
      "tool",
      "creative"
    ],
    "audiences": [
      "existing",
      "community"
    ],
    "hours": 2,
    "cost": "0 plus ongoing care",
    "approach": "Share useful progress and invite focused feedback in a relevant existing community",
    "measure": "Playtest participation, recurring use and qualitative themes",
    "risk": "Starting a new empty server creates moderation work before demand",
    "complexity": "Moderation and community rules",
    "maintainability": "Only open your own community when you can sustain it",
    "referenceIds": [
      "player-discovery"
    ],
    "planningScore": 4,
    "rationale": [
      "Format suits the project category",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "github",
    "name": "GitHub",
    "categories": [
      "tool"
    ],
    "audiences": [
      "developer",
      "coder",
      "engineer"
    ],
    "hours": 1,
    "cost": "0",
    "approach": "Useful README, working quickstart, example project and release notes",
    "measure": "Repository traffic plus downstream successful installs/use",
    "risk": "Stars can come from curiosity; rolling traffic history is short",
    "complexity": "Low; public metrics or repository-scoped read token",
    "maintainability": "Keep examples tested and collect traffic weekly",
    "referenceIds": [
      "github-traffic"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "hacker-news",
    "name": "Show HN",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "developer",
      "maker",
      "engineer"
    ],
    "hours": 2,
    "cost": "0",
    "approach": "Tryable substantive project, maker explanation and thoughtful replies",
    "measure": "Thread feedback and tagged product activation",
    "risk": "One-off generated projects and signup-only pages may be ineligible",
    "complexity": "Low setup; launch timing and discussion are unpredictable",
    "maintainability": "Be available for support; no repeated routine version posts",
    "referenceIds": [
      "channels",
      "hn-api"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "search",
    "name": "Search and useful documentation",
    "categories": [
      "tool",
      "app",
      "education"
    ],
    "audiences": [
      "learner",
      "developer",
      "user"
    ],
    "hours": 3,
    "cost": "0 plus sustained writing",
    "approach": "Answer a real recurring question with a useful page and a working example",
    "measure": "Qualified search visits and successful use",
    "risk": "Slow feedback; ranking is not guaranteed",
    "complexity": "Instrumentation, indexable pages and topic judgment",
    "maintainability": "Update examples and monitor query intent",
    "referenceIds": [
      "discovery",
      "measurement"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "linkedin",
    "name": "LinkedIn",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "professional",
      "business"
    ],
    "hours": 2,
    "cost": "0 for organic participation",
    "approach": "Concrete before/after workflow for the professional audience",
    "measure": "Qualified conversations and product use",
    "risk": "Impressions and generic praise can be weak demand signals",
    "complexity": "Requires clear professional relevance and a credible demo",
    "maintainability": "Reuse actual user stories with permission",
    "referenceIds": [
      "positioning",
      "measurement"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  },
  {
    "id": "product-hunt",
    "name": "Product Hunt",
    "categories": [
      "tool",
      "app"
    ],
    "audiences": [
      "maker",
      "early adopter"
    ],
    "hours": 3,
    "cost": "0 for a basic launch; verify current terms",
    "approach": "Prepared maker launch with concise gallery, demo and available support",
    "measure": "Tagged activation and thoughtful feedback",
    "risk": "Launch-day rank is not durable demand; do not solicit upvotes",
    "complexity": "Moderate preparation, fast discussion response",
    "maintainability": "Plan support and a follow-up beyond launch day",
    "referenceIds": [
      "product-hunt"
    ],
    "planningScore": 1,
    "rationale": [
      "Category fit needs evidence",
      "Verify that your intended people are present",
      "Fits 3 hours/week"
    ],
    "scoreMeaning": "House planning heuristic, not a reach or conversion forecast; verify policies when using the plan"
  }
]
```

```text
node scripts/marketing.mjs import .agent-marketing/brief-eval/with/strategy-new/initiative-patch.json --revision 0 --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "schema": "marketing/workspace@1",
  "revision": 1,
  "projects": [
    {
      "id": "orbit",
      "name": "Orbit Garden · demo",
      "audience": [
        "indie players",
        "relaxing-game fans"
      ],
      "category": "game",
      "problem": "A relaxing five-minute break",
      "promise": "Grow a little world in five minutes",
      "stage": "beta",
      "objective": "Learn whether 20 new players return for a second session",
      "weeklyHours": 3,
      "budget": 300,
      "currency": "USD"
    },
    {
      "id": "sketch",
      "name": "Sketch Relay · demo",
      "audience": [
        "developers",
        "creative makers"
      ],
      "category": "tool",
      "problem": "Sharing a quick UI idea takes too long",
      "promise": "Turn a rough sketch into a runnable interaction",
      "stage": "prototype",
      "objective": "Observe five successful first-use sessions",
      "weeklyHours": 2,
      "budget": 50,
      "currency": "USD"
    }
  ],
  "initiatives": [
    {
      "id": "orbit-video",
      "projectId": "orbit",
      "name": "A planet in one coffee break",
      "channel": "youtube",
      "hypothesis": "A clip of the payoff brings players who try a full round",
      "cta": "Play a five-minute round",
      "status": "paused",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio",
      "brief": {
        "markdown": "# A planet in one coffee break — synthetic campaign brief\n\n## Audience and hypothesis\nFor relaxing-game fans: a short clip of growing a tiny planet will bring players who complete a first round. This is a demonstration hypothesis, not a validated result.\n\n## Message, asset and CTA\nDraft caption: Grow a little world in five minutes. Show the first action and its visible payoff in a short gameplay capture. Asset: capture still to be produced. CTA: Play a five-minute round. No publication is authorized by this sample.\n\n## Measurement\nUse an initiative-tagged try link. Record attributed visitors and starts over the same period, plus a separately defined return cohort. Reach alone is not success. Inspect with: marketing report --project orbit --initiative orbit-video --workspace <ledger>.\n\n## Constraints and review\nOwner: Family studio. Dates: 2026-10-01 through 2026-10-14. Budget: 0 USD; cap clip preparation at one hour. Review on 2026-10-14. Continue only if observed players understand and complete the first action; change the try path if the same hesitation repeats; pause the clip if support or preparation exceeds the cap.\n\n## Evidence and limits\nRead the saved Orbit Garden strategy for the shared rationale. Demo source: https://example.com/demo-evidence. Synthetic counts do not establish channel effectiveness, payment intent or a causal effect.\n",
        "updatedAt": "2026-10-08T12:00:00.000Z"
      }
    },
    {
      "id": "orbit-playtest",
      "projectId": "orbit",
      "name": "First round playtest",
      "channel": "direct",
      "hypothesis": "Observing three unchanged first sessions reveals repeated first-action hesitation before increasing reach",
      "cta": "Try a round and describe where you hesitate",
      "status": "planned",
      "start": "2026-10-09",
      "end": "2026-10-15",
      "budget": 0,
      "owner": "Family studio"
    },
    {
      "id": "sketch-github",
      "projectId": "sketch",
      "name": "A working example worth cloning",
      "channel": "github",
      "hypothesis": "A short runnable example activates developers better than feature lists",
      "cta": "Run the starter example",
      "status": "running",
      "start": "2026-10-01",
      "end": "2026-10-14",
      "budget": 0,
      "owner": "Family studio"
    }
  ],
  "observations": [
    {
      "id": "orbit-views",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 2400,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "views",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-visitors",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "visitors",
      "value": 90,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-starts",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "starts",
      "value": 8,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-returns",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "returns",
      "value": 1,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "returns",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-cost",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "cost",
      "value": 0,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "cost",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "currency": "USD"
    },
    {
      "id": "orbit-daily-2026-10-01",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 160,
      "start": "2026-10-01",
      "end": "2026-10-01",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-02",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 220,
      "start": "2026-10-02",
      "end": "2026-10-02",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-03",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 180,
      "start": "2026-10-03",
      "end": "2026-10-03",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-04",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 390,
      "start": "2026-10-04",
      "end": "2026-10-04",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-05",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 420,
      "start": "2026-10-05",
      "end": "2026-10-05",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-06",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 510,
      "start": "2026-10-06",
      "end": "2026-10-06",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "orbit-daily-2026-10-07",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "metric": "views",
      "value": 520,
      "start": "2026-10-07",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "YouTube playback starts (daily demo)",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-visitors",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "visitors",
      "value": 62,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "visitors",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-starts",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "starts",
      "value": 18,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "period",
      "definition": "starts",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z"
    },
    {
      "id": "sketch-stars",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "metric": "stars",
      "value": 41,
      "start": "2026-10-01",
      "end": "2026-10-07",
      "kind": "snapshot",
      "definition": "stars",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "series": "sketch-stars"
    }
  ],
  "reactions": [
    {
      "id": "r1",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "The world looks beautiful. I did not know which seed to choose.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "onboarding"
    },
    {
      "id": "r2",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I love the tiny planet. Can I save and come back?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "return use"
    },
    {
      "id": "r3",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "Great art but the controls are confusing on my phone.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r4",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "I played once. The first round was fun.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "positive",
      "reviewed": true,
      "theme": "first session"
    },
    {
      "id": "r5",
      "projectId": "orbit",
      "initiativeId": "orbit-video",
      "channel": "youtube",
      "text": "What happens after the first five minutes?",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "unknown",
      "reviewed": false,
      "theme": "unclassified"
    },
    {
      "id": "r6",
      "projectId": "sketch",
      "initiativeId": "sketch-github",
      "channel": "github",
      "text": "Useful example. I needed clearer setup instructions.",
      "url": "https://example.com/demo-evidence",
      "collectedAt": "2026-10-08T06:00:00Z",
      "sentiment": "mixed",
      "reviewed": true,
      "theme": "installation"
    }
  ],
  "competitors": [
    {
      "id": "orbit-alt",
      "projectId": "orbit",
      "name": "Other relaxing browser games · illustrative",
      "kind": "direct",
      "positioning": "A familiar genre creates an expectation of an immediate playable loop",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": [
        {
          "dimension": "Time to payoff",
          "value": "Test your opening against a comparable five-minute game; no real competitor claim recorded",
          "url": "https://example.com/demo-evidence",
          "checkedAt": "2026-10-08"
        }
      ]
    },
    {
      "id": "orbit-do-nothing",
      "projectId": "orbit",
      "name": "Watch a relaxing video instead",
      "kind": "do-nothing",
      "positioning": "The player can spend the break watching rather than learning a new game",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    },
    {
      "id": "sketch-substitute",
      "projectId": "sketch",
      "name": "Screenshot plus chat message",
      "kind": "substitute",
      "positioning": "Already available and easy to share, but cannot demonstrate interaction",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08",
      "claims": []
    }
  ],
  "experiments": [
    {
      "id": "orbit-first-action",
      "projectId": "orbit",
      "name": "First action: label versus animated hint",
      "hypothesis": "A visible hint improves first-round starts",
      "primaryMetric": "Unique assigned visitors completing a first round within one session",
      "stoppingRule": "Analyze once after 100 assigned visitors per arm and a full seven-day window; stop early only for a broken flow",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · text label",
          "trials": 18,
          "successes": 3
        },
        {
          "name": "B · animated hint",
          "trials": 21,
          "successes": 5
        }
      ]
    },
    {
      "id": "sketch-install",
      "projectId": "sketch",
      "name": "Runnable README example versus feature list",
      "hypothesis": "A runnable example improves first successful setup",
      "primaryMetric": "Assigned developers successfully running the example",
      "stoppingRule": "Compare after 100 unique assigned visitors per arm over a full two-week window; report failures separately",
      "targetPerArm": 100,
      "randomized": true,
      "arms": [
        {
          "name": "A · feature list",
          "trials": 100,
          "successes": 11
        },
        {
          "name": "B · example",
          "trials": 100,
          "successes": 39
        }
      ]
    }
  ],
  "evidence": [
    {
      "id": "orbit-first-play",
      "projectId": "orbit",
      "dimension": "activation",
      "claim": "Eight attributed first sessions in the demo reporting window; identities and return cohort need verification",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "orbit-payment",
      "projectId": "orbit",
      "dimension": "payment",
      "claim": "No price test has been conducted in this synthetic example",
      "result": "unknown",
      "strength": "hypothesis",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    },
    {
      "id": "sketch-problem",
      "projectId": "sketch",
      "dimension": "problem",
      "claim": "Three synthetic maker interviews describe a recent need for a runnable sketch",
      "result": "supports",
      "strength": "primary",
      "url": "https://example.com/demo-evidence",
      "checkedAt": "2026-10-08"
    }
  ],
  "sources": []
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 1,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs document save strategy orbit .agent-marketing/brief-eval/with/strategy-new/strategy.md --revision 1 --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\strategy-new\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 2,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden: first-use strategy, 9–15 October 2026\n\nChoose direct, individually observed first sessions as this week's primary test. Owner: Family studio. Cap: three maker-hours and USD 0. The project's saved USD 300 budget is a general project figure, not permission to spend this week. No strategy was previously saved; this is a new rationale.\n\n## Evidence and assumptions\n\nThe isolated synthetic workspace contains 90 attributed visitors and eight starts in 1–7 October, plus a reviewed comment about not knowing which seed to choose and an unreviewed comment about mobile controls. These illustrate a possible first-use problem, not actual commercial evidence. The raw definitions are thin; 8/90 is only a descriptive example, not a validated conversion rate. One recorded return has no verified cohort, so do not calculate retention. Weekly and daily view rows overlap and must not be added. The existing hint experiment is below its declared stopping threshold; three sessions will not establish a winning variant.\n\nSource: supplied workspace observations, reactions, and evidence, whose https://example.com/demo-evidence link is a placeholder. Assumptions to check before execution: an actual playable build/URL, compatible device, and three willing first-time relaxing-game players are available. Availability and permission to contact them have not been established. Use direct, in-person sessions arranged by the owner; no community platform or posting permission is inferred.\n\n## Channel tradeoffs\n\n| Choice | Time and feedback lag | Cost and risk | Complexity and best practice | Maintenance |\n|---|---|---|---|---|\n| Direct first sessions, primary | 180 minutes total this week; immediate observation when sessions occur | USD 0; likely small convenience sample, substantial risk of coaching bias | Low technical setup; observe an unchanged build before prompting, separate observed behavior from opinion | Keep a short session sheet; bounded recruiting/support, not a new community |\n| Another YouTube clip, plausible alternative | About 60 minutes production plus responses/review; qualified play may lag days | USD 0 organic; further attention could expose the same confusion | Need truthful gameplay and working attribution; reach is not activation | Reuse capture, inspect comments, keep try link working; deferred this week |\n| YouTube, sustainable follow-up after first-use review | One reusable clip within a later three-hour week; response timing uncertain | USD 0; audience fit remains unproved | Existing channel record avoids new account/community setup; verify account access before publication | One bounded test with support and product outcomes, no daily posting commitment |\n\nThese are planning judgments. CLI ordering is a house heuristic, not evidence of performance. Current [YouTube spam rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive promotion and repetitive spam. [YouTube link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments do not have clickable URLs; long-form external links require advanced features. Checked 8 October 2026. If following up, use actual gameplay and verify the permitted try-link surface. Direct in-person observation has no community posting policy to verify. A player community remains conditional outside the ledger until audience, access, platform and local rules are identified.\n\n## One next test\n\nAudience → three first-time relaxing-game players. Message → “Try a short round and tell us where you hesitate.” Asset → current playable build plus one observation sheet. CTA → “Try a round and describe where you hesitate.” Do not show a tutorial first. Record device/build, time to first action, exact hesitation, help given and whether each player completes a round unaided.\n\nAllocate 25 minutes to build/device checks, 20 to owner-run scheduling and consent, 60 to three 20-minute sessions, 35 to synthesis, 20 to a proposed single clarification, and 20 to buffer. Stop at 180 minutes; if recruitment overruns, review available sessions and mark evidence insufficient. No posting, contact, spending or product change is executed by this plan.\n\nKeep stable initiative orbit-playtest, direct, planned, 9–15 October, owner Family studio, budget 0. Pause orbit-video growth work and preserve its record and brief. Primary outcome: count out of three who perform the first action and complete a round unaided; do not relabel historical starts. Record raw notes before aggregates; do not import planned values as observations.\n\n## Review decision: 15 October 2026\n\nIf all three complete unaided and the try path works, consider one later YouTube test with action-before-payoff footage. If two or more hesitate at the same point, keep growth paused and propose one first-use clarification, then retest. If fewer than three attend, decide on scheduling, not channel performance. Stop sessions on a broken build or the time cap. If first use is clear but a later tagged YouTube test brings unsuitable players, revisit audience/channel fit and investigate one verified player community. The next action now is to prepare the build check and observation sheet; increasing reach is premature until this question is resolved.\n",
    "updatedAt": "2026-10-08T19:09:40.418Z"
  }
}
```

```text
node scripts/marketing.mjs document show strategy orbit --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "workspace": "C:\\Users\\ehart\\repos\\agent-marketing\\.agent-marketing\\brief-eval\\with\\strategy-new\\workspace.json",
  "kind": "strategy",
  "id": "orbit",
  "projectId": "orbit",
  "name": "Orbit Garden · demo",
  "revision": 2,
  "location": "projects[id=orbit].strategy",
  "document": {
    "markdown": "# Orbit Garden: first-use strategy, 9–15 October 2026\n\nChoose direct, individually observed first sessions as this week's primary test. Owner: Family studio. Cap: three maker-hours and USD 0. The project's saved USD 300 budget is a general project figure, not permission to spend this week. No strategy was previously saved; this is a new rationale.\n\n## Evidence and assumptions\n\nThe isolated synthetic workspace contains 90 attributed visitors and eight starts in 1–7 October, plus a reviewed comment about not knowing which seed to choose and an unreviewed comment about mobile controls. These illustrate a possible first-use problem, not actual commercial evidence. The raw definitions are thin; 8/90 is only a descriptive example, not a validated conversion rate. One recorded return has no verified cohort, so do not calculate retention. Weekly and daily view rows overlap and must not be added. The existing hint experiment is below its declared stopping threshold; three sessions will not establish a winning variant.\n\nSource: supplied workspace observations, reactions, and evidence, whose https://example.com/demo-evidence link is a placeholder. Assumptions to check before execution: an actual playable build/URL, compatible device, and three willing first-time relaxing-game players are available. Availability and permission to contact them have not been established. Use direct, in-person sessions arranged by the owner; no community platform or posting permission is inferred.\n\n## Channel tradeoffs\n\n| Choice | Time and feedback lag | Cost and risk | Complexity and best practice | Maintenance |\n|---|---|---|---|---|\n| Direct first sessions, primary | 180 minutes total this week; immediate observation when sessions occur | USD 0; likely small convenience sample, substantial risk of coaching bias | Low technical setup; observe an unchanged build before prompting, separate observed behavior from opinion | Keep a short session sheet; bounded recruiting/support, not a new community |\n| Another YouTube clip, plausible alternative | About 60 minutes production plus responses/review; qualified play may lag days | USD 0 organic; further attention could expose the same confusion | Need truthful gameplay and working attribution; reach is not activation | Reuse capture, inspect comments, keep try link working; deferred this week |\n| YouTube, sustainable follow-up after first-use review | One reusable clip within a later three-hour week; response timing uncertain | USD 0; audience fit remains unproved | Existing channel record avoids new account/community setup; verify account access before publication | One bounded test with support and product outcomes, no daily posting commitment |\n\nThese are planning judgments. CLI ordering is a house heuristic, not evidence of performance. Current [YouTube spam rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive promotion and repetitive spam. [YouTube link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments do not have clickable URLs; long-form external links require advanced features. Checked 8 October 2026. If following up, use actual gameplay and verify the permitted try-link surface. Direct in-person observation has no community posting policy to verify. A player community remains conditional outside the ledger until audience, access, platform and local rules are identified.\n\n## One next test\n\nAudience → three first-time relaxing-game players. Message → “Try a short round and tell us where you hesitate.” Asset → current playable build plus one observation sheet. CTA → “Try a round and describe where you hesitate.” Do not show a tutorial first. Record device/build, time to first action, exact hesitation, help given and whether each player completes a round unaided.\n\nAllocate 25 minutes to build/device checks, 20 to owner-run scheduling and consent, 60 to three 20-minute sessions, 35 to synthesis, 20 to a proposed single clarification, and 20 to buffer. Stop at 180 minutes; if recruitment overruns, review available sessions and mark evidence insufficient. No posting, contact, spending or product change is executed by this plan.\n\nKeep stable initiative orbit-playtest, direct, planned, 9–15 October, owner Family studio, budget 0. Pause orbit-video growth work and preserve its record and brief. Primary outcome: count out of three who perform the first action and complete a round unaided; do not relabel historical starts. Record raw notes before aggregates; do not import planned values as observations.\n\n## Review decision: 15 October 2026\n\nIf all three complete unaided and the try path works, consider one later YouTube test with action-before-payoff footage. If two or more hesitate at the same point, keep growth paused and propose one first-use clarification, then retest. If fewer than three attend, decide on scheduling, not channel performance. Stop sessions on a broken build or the time cap. If first use is clear but a later tagged YouTube test brings unsuitable players, revisit audience/channel fit and investigate one verified player community. The next action now is to prepare the build check and observation sheet; increasing reach is premature until this question is resolved.\n",
    "updatedAt": "2026-10-08T19:09:40.418Z"
  }
}
```

```text
node scripts/marketing.mjs validate --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "ok": true,
  "revision": 2,
  "records": {
    "projects": 2,
    "initiatives": 3,
    "observations": 15,
    "reactions": 6,
    "competitors": 3,
    "experiments": 2,
    "evidence": 3,
    "sources": 0
  }
}
```

```text
node scripts/marketing.mjs report --project orbit --initiative orbit-playtest --from 2026-10-09 --to 2026-10-15 --workspace .agent-marketing/brief-eval/with/strategy-new/workspace.json
exit 0
{
  "filter": {
    "projectId": "orbit",
    "initiativeId": "orbit-playtest",
    "from": "2026-10-09",
    "to": "2026-10-15"
  },
  "uniqueReach": null,
  "totals": [],
  "observations": [],
  "reactions": [],
  "sentiment": {
    "positive": 0,
    "negative": 0,
    "neutral": 0,
    "mixed": 0,
    "unknown": 0,
    "unreviewed": 0
  },
  "funnels": [],
  "experiments": [],
  "competitors": [],
  "evidence": [],
  "sources": [],
  "warnings": [
    "Only observations fully contained in the date filter are included; period totals cannot be prorated.",
    "Platform audiences overlap. Unique reach and causal attribution are not inferred.",
    "Reactions are a self-selected sample; sentiment describes reviewed captured reactions only."
  ]
}
```

Readback equality: PASS. All prior record IDs retained; observations, reactions, competitors, experiments, evidence and sources byte-equivalent as parsed values. Final revision 2. No execution outcomes inserted.
