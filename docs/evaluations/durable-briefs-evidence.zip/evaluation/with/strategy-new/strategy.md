# Orbit Garden: first-use strategy, 9–15 October 2026

Choose direct, individually observed first sessions as this week's primary test. Owner: Family studio. Cap: three maker-hours and USD 0. The project's saved USD 300 budget is a general project figure, not permission to spend this week. No strategy was previously saved; this is a new rationale.

## Evidence and assumptions

The isolated synthetic workspace contains 90 attributed visitors and eight starts in 1–7 October, plus a reviewed comment about not knowing which seed to choose and an unreviewed comment about mobile controls. These illustrate a possible first-use problem, not actual commercial evidence. The raw definitions are thin; 8/90 is only a descriptive example, not a validated conversion rate. One recorded return has no verified cohort, so do not calculate retention. Weekly and daily view rows overlap and must not be added. The existing hint experiment is below its declared stopping threshold; three sessions will not establish a winning variant.

Source: supplied workspace observations, reactions, and evidence, whose https://example.com/demo-evidence link is a placeholder. Assumptions to check before execution: an actual playable build/URL, compatible device, and three willing first-time relaxing-game players are available. Availability and permission to contact them have not been established. Use direct, in-person sessions arranged by the owner; no community platform or posting permission is inferred.

## Channel tradeoffs

| Choice | Time and feedback lag | Cost and risk | Complexity and best practice | Maintenance |
|---|---|---|---|---|
| Direct first sessions, primary | 180 minutes total this week; immediate observation when sessions occur | USD 0; likely small convenience sample, substantial risk of coaching bias | Low technical setup; observe an unchanged build before prompting, separate observed behavior from opinion | Keep a short session sheet; bounded recruiting/support, not a new community |
| Another YouTube clip, plausible alternative | About 60 minutes production plus responses/review; qualified play may lag days | USD 0 organic; further attention could expose the same confusion | Need truthful gameplay and working attribution; reach is not activation | Reuse capture, inspect comments, keep try link working; deferred this week |
| YouTube, sustainable follow-up after first-use review | One reusable clip within a later three-hour week; response timing uncertain | USD 0; audience fit remains unproved | Existing channel record avoids new account/community setup; verify account access before publication | One bounded test with support and product outcomes, no daily posting commitment |

These are planning judgments. CLI ordering is a house heuristic, not evidence of performance. Current [YouTube spam rules](https://support.google.com/youtube/answer/2801973?hl=en) prohibit deceptive promotion and repetitive spam. [YouTube link guidance](https://support.google.com/youtube/answer/13748639?hl=en) says Shorts descriptions/comments do not have clickable URLs; long-form external links require advanced features. Checked 8 October 2026. If following up, use actual gameplay and verify the permitted try-link surface. Direct in-person observation has no community posting policy to verify. A player community remains conditional outside the ledger until audience, access, platform and local rules are identified.

## One next test

Audience → three first-time relaxing-game players. Message → “Try a short round and tell us where you hesitate.” Asset → current playable build plus one observation sheet. CTA → “Try a round and describe where you hesitate.” Do not show a tutorial first. Record device/build, time to first action, exact hesitation, help given and whether each player completes a round unaided.

Allocate 25 minutes to build/device checks, 20 to owner-run scheduling and consent, 60 to three 20-minute sessions, 35 to synthesis, 20 to a proposed single clarification, and 20 to buffer. Stop at 180 minutes; if recruitment overruns, review available sessions and mark evidence insufficient. No posting, contact, spending or product change is executed by this plan.

Keep stable initiative orbit-playtest, direct, planned, 9–15 October, owner Family studio, budget 0. Pause orbit-video growth work and preserve its record and brief. Primary outcome: count out of three who perform the first action and complete a round unaided; do not relabel historical starts. Record raw notes before aggregates; do not import planned values as observations.

## Review decision: 15 October 2026

If all three complete unaided and the try path works, consider one later YouTube test with action-before-payoff footage. If two or more hesitate at the same point, keep growth paused and propose one first-use clarification, then retest. If fewer than three attend, decide on scheduling, not channel performance. Stop sessions on a broken build or the time cap. If first use is clear but a later tagged YouTube test brings unsuitable players, revisit audience/channel fit and investigate one verified player community. The next action now is to prepare the build check and observation sheet; increasing reach is premature until this question is resolved.
