# Eight-case brief workflow evaluation

All eight target documents persist on the correct records, exactly match their brief files, and pass fresh native CLI validation. All seed record IDs, historical evidence and non-target saved documents are preserved. WITH scores 23/24 and BASELINE 20/24 under the strict retained-readback-evidence criterion. These totals do not establish skill superiority: four deductions concern unequal evidence retention, and the one substantive constraint failure is in WITH.

## Criteria and scores

- **C1**: Full new/revised document persists on correct record.
- **C2**: Usable reasoning/execution detail; honest synthetic evidence and assumptions.
- **C3**: Saved plan/initiative consistent with task, constraints and review decision.
- **C4**: Prior records and other saved documents preserved.
- **C5**: Actual saved-content readback evidenced and durable location communicated.
- **C6**: Valid revision-aware workflow; no unauthorized external action evidenced.

| Mode | Case | C1 | C2 | C3 | C4 | C5 | C6 | Total |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| with | strategy-new | 1 | 1 | 1 | 1 | 1 | 1 | 6/6 |
| with | strategy-revise | 1 | 1 | 1 | 1 | 1 | 1 | 6/6 |
| with | campaign-new | 1 | 1 | 1 | 1 | 1 | 1 | 6/6 |
| with | campaign-revise | 1 | 1 | 0 | 1 | 1 | 1 | 5/6 |
| baseline | strategy-new | 1 | 1 | 1 | 1 | 0 | 1 | 5/6 |
| baseline | strategy-revise | 1 | 1 | 1 | 1 | 0 | 1 | 5/6 |
| baseline | campaign-new | 1 | 1 | 1 | 1 | 0 | 1 | 5/6 |
| baseline | campaign-revise | 1 | 1 | 1 | 1 | 0 | 1 | 5/6 |

## Content failure

**WITH / campaign-revise, C3 = 0.** The user's request says “Keep its existing limits and attribution plan.” The seed brief says “cap clip preparation at one hour” and “pause the clip if support or preparation exceeds the cap.” The saved revision instead says “Fit response/review work within the project's three-hour weekly cap” (campaign.md:24), then “pause if preparation/support exceeds capacity” (line 50). It keeps a precise 60-minute preparation stop but no longer retains the original one-hour support stop. This weakens a requested constraint; it is a content/constraint error, not a persistence or schema error. The caption, action-before-payoff outline, attribution, dates, owner and budget otherwise satisfy the task.

**BASELINE / campaign-revise preserves this constraint.** Its brief says “Pause if preparation or support exceeds the existing cap; count both when judging whether this iteration fits the hour” (brief.md:3), and “Support effort consumes the same bounded iteration allowance” (line 30). No corresponding C3 deduction.

## Operational evidence gaps

**All four BASELINE cases, C5 = 0.** Each response claims: “Final verification used an inline Node script via PowerShell here-string piped to `node --input-type=module`.” It says an equality assertion passed, but the actual script and output are absent. Save commands and results are summarized in prose; no actual post-save document-show output is retained. Each response does communicate its durable record location. Fresh independent readback confirms all four documents exist and match now; that does not establish the agent performed the claimed readback. These deductions mean missing verification evidence, not failed persistence.

**All four WITH cases, C5 = 1.** Each commands.md retains a successful post-save `document show` command and complete returned Markdown at revision 2. I parsed those outputs and confirmed exact equality with the final saved target and brief. Responses name the workspace and UI reopening location.

## Other findings, applied equally

Both modes produce usable full strategies and campaign plans. Strategies identify a direct three-session test, three-hour/$0 allocation, synthetic evidence limitations, conditional channel choices and review rules. Campaigns supply draft copy, timed execution outlines, observation definitions and continue/change/stop criteria. All distinguish historical synthetic counts from future outcomes, avoid interpreting the lone return as retention, and mark missing actual game URLs/build details and participant access as prerequisites. No invented results were added.

WITH imports task-related initiative changes at revision 0, validates revision 1, then saves its document at revision 1 to reach revision 2. BASELINE validates revision 0 and saves to revision 1. Those documented write workflows are valid. WITH preserves prior campaign briefs during its full-record imports. BASELINE changes only the target document and workspace revision. Native final record counts are identical for all cases: 2 projects, 3 initiatives, 15 observations, 6 reactions, 3 competitors, 2 experiments, 3 evidence, 0 sources.

BASELINE strategy plans explicitly pause further reach work while retaining the existing clip's running metadata. I do not infer a requirement to deactivate an existing published clip from “pause increasing reach”; this is not a C3 failure. WITH additionally marks the video paused in its strategy cases. Existing stable IDs and unrelated documents survive both approaches.

Recovered command issues: BASELINE strategy-new attempted unsupported `--help`, received `E_USAGE`, then inspected the entrypoint/README and successfully saved. A shell Import-Clixml diagnostic was also reported. WITH strategy-new and campaign-new initially received “No ... document saved” from document show, an expected result for new documents. None is an unresolved operational failure. No recorded workflow sends messages, publishes, or spends.

## Scope and verification

Read tasks.json, all responses, full brief files, final ledgers, available before snapshots, command artifacts, seed examples/studio.json and native document/schema implementation. For strategy-new, the comparison seed omits the initially absent strategy. Ran `node scripts/marketing.mjs validate --workspace <case>/workspace.json` for each of the eight cases; every result was ok. Parsed records were compared, rather than relying on unchanged counts or agents' preservation claims. Original artifacts were not edited. Structured evidence and changed paths are in [grade.json](grade.json).

This is a small paired workflow check on one synthetic workspace. It is not a superiority or safety proof. The logs themselves are retained agent artifacts, and their evidence granularity differs between modes. No claim about campaign effectiveness, statistical significance or general reliability follows from these scores.
